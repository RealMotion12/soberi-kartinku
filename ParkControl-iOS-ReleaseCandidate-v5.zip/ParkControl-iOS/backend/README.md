# ParkControl production API

## Included
- PostgreSQL multi-tenant organization model
- owner/admin roles
- email/password registration and login
- JWT sessions
- vehicles CRUD
- employees
- inspections with mileage update
- expenses
- account deletion
- Apple App Store Server Notifications V2 endpoint
- Helmet, CORS and rate limiting
- Docker image

## Run
1. Copy `.env.example` to `.env` and set secrets.
2. Create PostgreSQL database.
3. `psql "$DATABASE_URL" -f sql/schema.sql`
4. `npm ci`
5. `npm start`

## Apple subscriptions
Product ID is `com.realmotion12.parkcontrol.pro.monthly`.
Create the auto-renewable subscription in App Store Connect and configure
Production/Sandbox App Store Server Notifications V2 to:
`https://YOUR_DOMAIN/api/v1/apple/notifications`

Apple's official Node library is used for signed JWS notification verification.
Download Apple root certificates and set `APPLE_ROOT_CA_PATHS`.
Set the numeric App Store app ID in `APPLE_APPLE_ID`.

For a real launch, map verified transaction `appAccountToken` to the ParkControl
user/organization and reconcile all subscription lifecycle events. Never put
Apple private keys or JWT secrets in the iOS app.

## Security
- Use HTTPS only.
- Put PostgreSQL on a private network.
- Rotate JWT secrets and database credentials.
- Add daily backups and tested restore.
- Store uploaded documents/photos in private object storage with signed URLs.
- Add audit logging before onboarding paying fleets.
