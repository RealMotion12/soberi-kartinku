# ParkControl API starter

PostgreSQL-backed organization-scoped fleet API.

Environment:
DATABASE_URL=postgresql://...
PORT=8080

Run:
npm install
psql "$DATABASE_URL" -f sql/schema.sql
npm start

For production add authentication/JWT or OIDC, authorization on every route,
audit logs, object storage for documents/photos, rate limiting, backups, and
App Store Server API + Notifications V2 subscription verification.
