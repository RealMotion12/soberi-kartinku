create extension if not exists pgcrypto;
create table if not exists organizations(
 id uuid primary key default gen_random_uuid(),
 name text not null, created_at timestamptz not null default now());
create table if not exists vehicles(
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references organizations(id) on delete cascade,
 brand text not null, model text not null, plate text not null,
 mileage integer not null default 0, status text not null default 'idle',
 next_service text, insurance_until date, created_at timestamptz not null default now(),
 unique(organization_id,plate));
create table if not exists employees(
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references organizations(id) on delete cascade,
 name text not null, role text not null default 'observer',
 created_at timestamptz not null default now());
create table if not exists inspections(
 id uuid primary key default gen_random_uuid(),
 vehicle_id uuid not null references vehicles(id) on delete cascade,
 employee_id uuid references employees(id) on delete set null,
 mileage integer not null, passed boolean not null default true,
 comment text, created_at timestamptz not null default now());
create table if not exists expenses(
 id uuid primary key default gen_random_uuid(),
 vehicle_id uuid not null references vehicles(id) on delete cascade,
 amount numeric(12,2) not null, category text not null, comment text,
 created_at timestamptz not null default now());
