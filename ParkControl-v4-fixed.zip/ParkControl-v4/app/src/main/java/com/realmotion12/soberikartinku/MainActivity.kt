package com.realmotion12.soberikartinku

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

data class Car(
    val brand: String,
    val model: String,
    val plate: String,
    val status: String,
    val mileage: String,
    val insurance: String,
    val service: String
)

class MainActivity : Activity() {
    private lateinit var ui: ParkControlView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 11, 12)
        window.navigationBarColor = Color.rgb(11, 11, 12)
        ui = ParkControlView()
        setContentView(ui)
    }

    private fun mileageDialog() {
        val input = EditText(this).apply {
            hint = "Например, 184250"
            inputType = 2
            setPadding(32, 18, 32, 18)
        }
        AlertDialog.Builder(this)
            .setTitle("Текущий пробег")
            .setMessage("Показание одометра обязательно для завершения осмотра")
            .setView(input)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Продолжить") { _, _ ->
                val value = input.text.toString().toIntOrNull()
                if (value == null) {
                    Toast.makeText(this, "Введите корректный пробег", Toast.LENGTH_SHORT).show()
                } else {
                    ui.mileage = value
                    ui.inspectionStep = 1
                    ui.invalidate()
                }
            }.show()
    }

    private fun openCamera() {
        try {
            startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 100)
        } catch (_: Exception) {
            Toast.makeText(this, "Камера недоступна", Toast.LENGTH_SHORT).show()
        }
    }

    inner class ParkControlView : View(this) {
        private val bg = Color.rgb(11, 11, 12)
        private val card = Color.rgb(21, 21, 23)
        private val card2 = Color.rgb(27, 27, 30)
        private val white = Color.rgb(245, 245, 247)
        private val muted = Color.rgb(160, 160, 165)
        private val yellow = Color.rgb(255, 204, 0)
        private val green = Color.rgb(52, 199, 89)
        private val red = Color.rgb(255, 69, 58)
        private val blue = Color.rgb(90, 200, 250)
        private val orange = Color.rgb(255, 159, 10)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val text = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG)
        private val density = resources.displayMetrics.density
        private var screen = 0
        private var selectedCar = 0
        var mileage = 184250
        var inspectionStep = 0
        private val inspectionNames = listOf("Спереди", "Слева", "Справа", "Сзади", "Багажник")
        private val checks = listOf(
            "СТС", "Страховка", "Диагностическая карта", "Шашка", "Салон чистый",
            "Аптечка", "Огнетушитель", "Знак аварийной остановки", "Запасное колесо", "Домкрат",
            "Ремень безопасности", "Фары", "Шины"
        )
        private val checked = BooleanArray(checks.size)
        private val cars = listOf(
            Car("Toyota", "Camry", "А123АА", "На линии", "184 250 км", "14.11.26", "190 000 км"),
            Car("Kia", "K5", "В456ВВ", "На линии", "126 840 км", "02.12.26", "130 000 км"),
            Car("Hyundai", "Solaris", "С789СС", "В ремонте", "211 420 км", "28.10.26", "220 000 км"),
            Car("Skoda", "Octavia", "Е321ЕЕ", "Простой", "98 540 км", "19.01.27", "100 000 км")
        )

        init {
            setBackgroundColor(bg)
            text.typeface = Typeface.create("sans", Typeface.NORMAL)
            p.strokeCap = Paint.Cap.ROUND
        }

        private fun d(v: Float) = v * density
        private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
            p.style = Paint.Style.FILL
            p.color = color
            c.drawRoundRect(d(l), d(t), d(r), d(b), d(radius), d(radius), p)
        }
        private fun tx(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = white, bold: Boolean = false) {
            text.textSize = d(size)
            text.color = color
            text.typeface = Typeface.create("sans", if (bold) Typeface.BOLD else Typeface.NORMAL)
            c.drawText(s, d(x), d(y), text)
        }
        private fun center(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = white, bold: Boolean = false) {
            text.textSize = d(size)
            text.typeface = Typeface.create("sans", if (bold) Typeface.BOLD else Typeface.NORMAL)
            text.color = color
            c.drawText(s, d(x) - text.measureText(s) / 2f, d(y), text)
        }
        private fun icon(c: Canvas, s: String, x: Float, y: Float, size: Float = 22f, color: Int = white) = center(c, s, x, y, size, color, false)

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            c.drawColor(bg)
            when (screen) {
                0 -> drawDashboard(c)
                1 -> drawCars(c)
                2 -> drawInspections(c)
                3 -> drawMore(c)
                4 -> drawCarDetail(c)
                5 -> drawInspection(c)
            }
            if (screen <= 3) drawNav(c)
        }

        private fun header(c: Canvas, eyebrow: String, title: String, right: String? = null) {
            tx(c, eyebrow.uppercase(), 20f, 32f, 11f, muted, true)
            tx(c, title, 20f, 66f, 30f, white, true)
            if (right != null) {
                rr(c, 316f, 38f, 356f, 78f, 20f, card2)
                center(c, right, 336f, 64f, 18f, yellow, true)
            }
        }

        private fun drawDashboard(c: Canvas) {
            header(c, "ПаркКонтроль", "Добрый вечер", "⚙")
            tx(c, "Контроль автопарка в одном месте", 20f, 91f, 14f, muted)

            rr(c, 20f, 110f, 356f, 258f, 24f, card)
            tx(c, "АВТОПАРК", 40f, 140f, 11f, muted, true)
            tx(c, "148", 40f, 190f, 50f, white, true)
            tx(c, "автомобилей", 42f, 214f, 14f, muted)
            rr(c, 40f, 239f, 152f, 300f, 16f, card2)
            rr(c, 164f, 239f, 276f, 300f, 16f, card2)
            tx(c, "● 132", 55f, 264f, 18f, green, true)
            tx(c, "На линии", 55f, 286f, 12f, muted)
            tx(c, "🔧 12", 179f, 264f, 18f, orange, true)
            tx(c, "В ремонте", 179f, 286f, 12f, muted)
            tx(c, "4", 292f, 264f, 18f, muted, true)
            tx(c, "Простой", 292f, 286f, 12f, muted)
            tx(c, "89%", 40f, 340f, 14f, yellow, true)
            tx(c, "автомобилей сейчас на линии", 82f, 340f, 12f, muted)

            tx(c, "Требует внимания", 20f, 401f, 20f, white, true)
            smallMetric(c, 20f, 420f, 191f, 500f, "🔧", "15", "осмотров сегодня", yellow)
            smallMetric(c, 205f, 420f, 376f, 500f, "📄", "3", "документа скоро", orange)
            smallMetric(c, 20f, 512f, 191f, 592f, "🛠", "7", "ТО по пробегу", blue)
            smallMetric(c, 205f, 512f, 376f, 592f, "₽", "42 800", "расходы сегодня", green)

            rr(c, 20f, 616f, 376f, 706f, 22f, yellow)
            tx(c, "Осмотры на сегодня", 40f, 648f, 16f, Color.BLACK, true)
            tx(c, "15 автомобилей ожидают проверку", 40f, 672f, 13f, Color.rgb(55, 50, 0))
            center(c, "›", 350f, 666f, 28f, Color.BLACK, true)
        }

        private fun smallMetric(c: Canvas, l: Float, t: Float, r: Float, b: Float, ico: String, num: String, label: String, color: Int) {
            rr(c, l, t, r, b, 20f, card)
            icon(c, ico, l + 28f, t + 31f, 19f, color)
            tx(c, num, l + 51f, t + 34f, 19f, white, true)
            tx(c, label, l + 18f, t + 61f, 11f, muted)
        }

        private fun drawCars(c: Canvas) {
            header(c, "Автопарк", "Автомобили", "+")
            rr(c, 20f, 86f, 376f, 130f, 16f, card)
            tx(c, "⌕", 39f, 114f, 22f, muted)
            tx(c, "Поиск по номеру или модели", 66f, 114f, 14f, muted)
            val filters = listOf("Все", "На линии", "Ремонт", "Простой")
            var x = 20f
            filters.forEachIndexed { i, f ->
                val w = if (i == 0) 58f else 92f
                rr(c, x, 143f, x + w, 179f, 18f, if (i == 0) yellow else card)
                center(c, f, x + w / 2, 166f, 12f, if (i == 0) Color.BLACK else muted, i == 0)
                x += w + 8f
            }
            tx(c, "148 автомобилей", 20f, 211f, 13f, muted)
            var y = 228f
            cars.forEachIndexed { i, car ->
                vehicleCard(c, car, y, i)
                y += 116f
                if (y > 675f) return@forEachIndexed
            }
        }

        private fun vehicleCard(c: Canvas, car: Car, y: Float, index: Int) {
            rr(c, 20f, y, 376f, y + 104f, 20f, card)
            rr(c, 34f, y + 17f, 70f, y + 70f, 16f, card2)
            center(c, "🚕", 52f, y + 51f, 23f)
            tx(c, "${car.brand} ${car.model}", 86f, y + 31f, 16f, white, true)
            tx(c, car.plate, 86f, y + 54f, 13f, muted)
            val col = when (car.status) { "На линии" -> green; "В ремонте" -> orange; else -> muted }
            tx(c, "● ${car.status}", 86f, y + 80f, 12f, col, true)
            tx(c, car.mileage, 274f, y + 31f, 13f, white, true)
            tx(c, "ТО ${car.service}", 274f, y + 53f, 11f, muted)
            center(c, "›", 351f, y + 82f, 22f, yellow, true)
        }

        private fun drawInspections(c: Canvas) {
            header(c, "Контроль", "Осмотры", "15")
            tx(c, "Сегодня нужно пройти 15 осмотров", 20f, 92f, 14f, muted)
            rr(c, 20f, 110f, 376f, 168f, 22f, yellow)
            tx(c, "СЕГОДНЯ", 40f, 137f, 11f, Color.rgb(65, 58, 0), true)
            tx(c, "15", 40f, 163f, 30f, Color.BLACK, true)
            tx(c, "авто ожидают осмотр", 83f, 160f, 14f, Color.rgb(65, 58, 0))
            tx(c, "Просрочено: 2", 40f, 190f, 12f, Color.rgb(65, 58, 0), true)
            center(c, "→", 340f, 162f, 25f, Color.BLACK, true)

            tx(c, "Очередь", 20f, 314f, 20f, white, true)
            val list = listOf(cars[0], cars[1], cars[3])
            list.forEachIndexed { i, car ->
                rr(c, 20f, 330f + i * 96f, 376f, 414f + i * 96f, 18f, card)
                tx(c, "${car.brand} ${car.model}", 38f, 358f + i * 96f, 15f, white, true)
                tx(c, car.plate, 38f, 380f + i * 96f, 12f, muted)
                rr(c, 268f, 349f + i * 96f, 356f, 393f + i * 96f, 16f, if (i == 2) Color.rgb(55, 35, 34) else card2)
                center(c, if (i == 2) "Просрочено" else "Начать", 312f, 377f + i * 96f, 11f, if (i == 2) red else yellow, true)
            }
            rr(c, 20f, 620f, 376f, 680f, 18f, card2)
            center(c, "Настройка графика: каждые 7 дней", 198f, 657f, 13f, white, true)
        }

        private fun drawMore(c: Canvas) {
            header(c, "Настройки", "Ещё", "⋯")
            menuRow(c, 20f, 96f, "👥", "Сотрудники", "Роли и разрешения")
            menuRow(c, 20f, 164f, "🔔", "Уведомления", "Что и кому отправлять")
            menuRow(c, 20f, 232f, "📊", "Отчёты", "Парк, расходы, ремонты")
            menuRow(c, 20f, 300f, "📥", "Excel", "Импорт и экспорт парка")
            menuRow(c, 20f, 368f, "↔", "Интеграции", "1С и внешние системы")
            menuRow(c, 20f, 436f, "⚙", "Настройки парка", "Осмотры, ТО, документы")
            rr(c, 20f, 528f, 376f, 620f, 22f, card)
            tx(c, "ПАРККОНТРОЛЬ", 42f, 560f, 11f, muted, true)
            tx(c, "Версия 4.0", 42f, 589f, 18f, white, true)
            tx(c, "Премиальный контроль автопарка", 42f, 610f, 12f, muted)
        }

        private fun menuRow(c: Canvas, l: Float, t: Float, ico: String, title: String, sub: String) {
            rr(c, l, t, 376f, t + 56f, 18f, card)
            center(c, ico, 49f, t + 35f, 19f, yellow)
            tx(c, title, 76f, t + 25f, 15f, white, true)
            tx(c, sub, 76f, t + 44f, 11f, muted)
            center(c, "›", 351f, t + 35f, 22f, muted, true)
        }

        private fun drawCarDetail(c: Canvas) {
            tx(c, "‹", 24f, 48f, 34f, white, false)
            tx(c, "Автомобиль", 58f, 43f, 14f, muted)
            tx(c, "Toyota Camry", 20f, 92f, 29f, white, true)
            tx(c, "А123АА", 20f, 119f, 14f, muted)
            rr(c, 20f, 140f, 376f, 204f, 22f, card)
            tx(c, "● На линии", 40f, 169f, 14f, green, true)
            tx(c, "184 250 км", 40f, 193f, 24f, white, true)
            tx(c, "Пробег обновлён сегодня", 40f, 219f, 11f, muted)
            infoTile(c, 20f, 224f, "ОСАГО", "14.11.26", yellow)
            infoTile(c, 206f, 224f, "СЛЕДУЮЩЕЕ ТО", "190 000 км", blue)
            tx(c, "Быстрые действия", 20f, 430f, 19f, white, true)
            action(c, 20f, 448f, "🔧", "Осмотр", yellow)
            action(c, 206f, 448f, "🛠", "Ремонт", orange)
            action(c, 20f, 520f, "📄", "Документы", blue)
            action(c, 206f, 520f, "₽", "Расход", green)
            tx(c, "История", 20f, 622f, 19f, white, true)
            tx(c, "Сегодня · Осмотр · 184 250 км", 20f, 650f, 13f, muted)
            tx(c, "18.09 · ТО · 180 120 км", 20f, 675f, 13f, muted)
        }

        private fun infoTile(c: Canvas, x: Float, y: Float, label: String, value: String, color: Int) {
            rr(c, x, y, x + 170f, y + 92f, 20f, card)
            tx(c, label, x + 18f, y + 29f, 10f, muted, true)
            tx(c, value, x + 18f, y + 60f, 17f, color, true)
        }

        private fun action(c: Canvas, x: Float, y: Float, ico: String, label: String, color: Int) {
            rr(c, x, y, x + 170f, y + 60f, 18f, card)
            center(c, ico, x + 29f, y + 37f, 18f, color)
            tx(c, label, x + 55f, y + 39f, 14f, white, true)
        }

        private fun drawInspection(c: Canvas) {
            tx(c, "‹", 24f, 48f, 34f, white)
            tx(c, "Осмотр", 58f, 43f, 14f, muted)
            tx(c, "Toyota Camry · А123АА", 20f, 88f, 22f, white, true)
            tx(c, "Шаг ${inspectionStep + 1} из 8", 20f, 113f, 12f, muted)
            for (i in 0 until 8) {
                rr(c, 20f + i * 44f, 128f, 58f + i * 44f, 132f, 2f, if (i <= inspectionStep) yellow else card2)
            }
            when {
                inspectionStep == 0 -> {
                    rr(c, 20f, 160f, 376f, 330f, 26f, card)
                    center(c, "📏", 198f, 220f, 40f)
                    center(c, "Текущий пробег", 198f, 264f, 25f, white, true)
                    center(c, "Показание одометра обязательно", 198f, 291f, 13f, muted)
                    rr(c, 72f, 304f, 324f, 314f, 5f, card2)
                    center(c, "$mileage км", 198f, 300f, 0f)
                    rr(c, 40f, 350f, 356f, 404f, 18f, yellow)
                    center(c, "Ввести пробег", 198f, 384f, 15f, Color.BLACK, true)
                    tx(c, "После ввода можно сфотографировать одометр", 40f, 435f, 12f, muted)
                }
                inspectionStep in 1..5 -> {
                    val idx = inspectionStep - 1
                    rr(c, 20f, 160f, 376f, 520f, 26f, card)
                    center(c, "📷", 198f, 250f, 54f, yellow)
                    center(c, inspectionNames[idx], 198f, 305f, 27f, white, true)
                    center(c, "Сделайте фото автомобиля", 198f, 334f, 13f, muted)
                    rr(c, 55f, 380f, 341f, 436f, 20f, yellow)
                    center(c, "Открыть камеру", 198f, 416f, 15f, Color.BLACK, true)
                    center(c, "Фото ${idx + 1} / 5", 198f, 478f, 12f, muted)
                }
                inspectionStep == 6 -> drawChecklist(c)
                else -> {
                    rr(c, 20f, 160f, 376f, 410f, 26f, card)
                    center(c, "✓", 198f, 238f, 58f, green, true)
                    center(c, "Осмотр готов", 198f, 290f, 26f, white, true)
                    center(c, "Пробег: $mileage км", 198f, 319f, 14f, muted)
                    rr(c, 40f, 350f, 356f, 404f, 18f, yellow)
                    center(c, "Сохранить осмотр", 198f, 384f, 15f, Color.BLACK, true)
                }
            }
        }

        private fun drawChecklist(c: Canvas) {
            tx(c, "Чек-лист", 20f, 176f, 23f, white, true)
            tx(c, "Проверьте наличие и состояние", 20f, 201f, 13f, muted)
            var y = 222f
            checks.forEachIndexed { i, item ->
                rr(c, 20f, y, 376f, y + 48f, 16f, card)
                tx(c, item, 38f, y + 30f, 13f, white)
                rr(c, 329f, y + 10f, 360f, y + 38f, 14f, if (checked[i]) green else card2)
                center(c, if (checked[i]) "✓" else "", 344f, y + 31f, 15f, Color.WHITE, true)
                y += 54f
                if (y > 670f) return@forEachIndexed
            }
        }

        private fun drawNav(c: Canvas) {
            rr(c, 12f, 720f, 384f, 796f, 24f, Color.rgb(20, 20, 22))
            val labels = arrayOf("⌂", "🚕", "✓", "⋯")
            val names = arrayOf("Главная", "Парк", "Осмотры", "Ещё")
            for (i in 0..3) {
                val x = 60f + i * 96f
                val active = screen == i
                if (active) rr(c, x - 25f, 731f, x + 25f, 759f, 14f, Color.rgb(49, 44, 8))
                center(c, labels[i], x, 751f, 20f, if (active) yellow else muted)
                center(c, names[i], x, 779f, 10f, if (active) white else muted, active)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action != MotionEvent.ACTION_UP) return true
            val x = e.x / density
            val y = e.y / density

            if (screen <= 3 && y >= 710f) {
                screen = min(3, max(0, ((x - 12f) / 96f).toInt()))
                invalidate()
                return true
            }

            when (screen) {
                0 -> if (y in 610f..715f) { screen = 2; invalidate() }
                1 -> if (y >= 220f) { selectedCar = min(cars.lastIndex, ((y - 228f) / 116f).toInt()); screen = 4; invalidate() }
                2 -> if (y in 330f..620f) { screen = 5; inspectionStep = 0; invalidate() }
                4 -> if (y < 70f) { screen = 1; invalidate() } else if (y in 440f..515f && x < 200f) { screen = 5; inspectionStep = 0; invalidate() }
                5 -> handleInspectionTouch(x, y)
            }
            return true
        }

        private fun handleInspectionTouch(x: Float, y: Float) {
            if (y < 70f) { screen = 4; invalidate(); return }
            when {
                inspectionStep == 0 && y in 330f..420f -> mileageDialog()
                inspectionStep in 1..5 && y in 360f..450f -> {
                    openCamera()
                    inspectionStep++
                    invalidate()
                }
                inspectionStep == 6 -> {
                    val idx = ((y - 222f) / 54f).toInt()
                    if (idx in checked.indices) {
                        checked[idx] = !checked[idx]
                        invalidate()
                    }
                    if (y > 640f) {
                        inspectionStep = 7
                        invalidate()
                    }
                }
                inspectionStep == 7 && y in 340f..430f -> {
                    Toast.makeText(this@MainActivity, "Осмотр сохранён", Toast.LENGTH_SHORT).show()
                    screen = 2
                    invalidate()
                }
            }
        }
    }
}
