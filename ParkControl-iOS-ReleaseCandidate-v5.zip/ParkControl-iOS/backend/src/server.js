
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pg from "pg";
import fs from "fs";
import {
  SignedDataVerifier, Environment
} from "@apple/app-store-server-library";

const { Pool } = pg;
const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(",").map(x => x.trim()) || true }));
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300 }));

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) console.warn("JWT_SECRET is not set. Set it before production.");
const PRODUCT_ID = process.env.APPLE_PRODUCT_ID || "com.realmotion12.parkcontrol.pro.monthly";

function tokenFor(user) {
  return jwt.sign({ sub: user.id, org: user.organization_id, role: user.role }, JWT_SECRET, { expiresIn: "30d" });
}
function auth(req, res, next) {
  try {
    const raw = req.headers.authorization || "";
    if (!raw.startsWith("Bearer ")) return res.status(401).json({ error: "unauthorized" });
    req.user = jwt.verify(raw.slice(7), JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: "unauthorized" }); }
}
async function requireOwner(req, res, next) {
  if (!["owner","admin"].includes(req.user.role)) return res.status(403).json({ error: "forbidden" });
  next();
}

app.get("/health", async (_req,res) => {
  try { await pool.query("select 1"); res.json({ ok:true, service:"parkcontrol-api" }); }
  catch { res.status(503).json({ ok:false }); }
});

app.post("/api/v1/auth/register", async (req,res) => {
  const { email, password, organizationName } = req.body || {};
  if (!email || !password || !organizationName || password.length < 8)
    return res.status(400).json({ error:"email, organizationName and password(8+) required" });
  const client = await pool.connect();
  try {
    await client.query("begin");
    const org = await client.query("insert into organizations(name) values($1) returning id,name", [organizationName]);
    const hash = await bcrypt.hash(password, 12);
    const user = await client.query(
      "insert into users(organization_id,email,password_hash,role) values($1,$2,$3,'owner') returning id,organization_id,email,role",
      [org.rows[0].id, email.toLowerCase(), hash]);
    await client.query("commit");
    res.status(201).json({ token: tokenFor(user.rows[0]), user:user.rows[0], organization:org.rows[0] });
  } catch(e) {
    await client.query("rollback");
    if (e.code === "23505") return res.status(409).json({ error:"email already exists" });
    res.status(500).json({ error:"server_error" });
  } finally { client.release(); }
});

app.post("/api/v1/auth/login", async (req,res) => {
  const { email, password } = req.body || {};
  const { rows } = await pool.query("select * from users where email=$1", [email?.toLowerCase()]);
  if (!rows[0] || !(await bcrypt.compare(password || "", rows[0].password_hash)))
    return res.status(401).json({ error:"invalid_credentials" });
  const u = rows[0];
  const org = await pool.query("select id,name from organizations where id=$1", [u.organization_id]);
  res.json({ token:tokenFor(u), user:{id:u.id,organization_id:u.organization_id,email:u.email,role:u.role}, organization:org.rows[0] });
});

app.get("/api/v1/me", auth, async (req,res) => {
  const { rows } = await pool.query(
    `select u.id,u.email,u.role,o.id organization_id,o.name organization_name
     from users u join organizations o on o.id=u.organization_id where u.id=$1`, [req.user.sub]);
  if (!rows[0]) return res.status(404).json({ error:"not_found" });
  const sub = await pool.query(
    `select product_id,expires_at,status,environment from subscriptions
     where organization_id=$1 order by updated_at desc limit 1`, [req.user.org]);
  res.json({ user:rows[0], subscription:sub.rows[0] || null });
});

app.get("/api/v1/vehicles", auth, async (req,res) => {
  const { rows } = await pool.query(
    `select id,brand,model,plate,mileage,status,next_service,insurance_until
     from vehicles where organization_id=$1 order by created_at desc`, [req.user.org]);
  res.json(rows);
});

app.post("/api/v1/vehicles", auth, async (req,res) => {
  const {brand,model,plate,mileage=0,status="idle",nextService=null,insuranceUntil=null}=req.body||{};
  if(!brand||!model||!plate) return res.status(400).json({error:"brand,model,plate required"});
  try {
    const {rows}=await pool.query(
      `insert into vehicles(organization_id,brand,model,plate,mileage,status,next_service,insurance_until)
       values($1,$2,$3,$4,$5,$6,$7,$8)
       returning id,brand,model,plate,mileage,status,next_service,insurance_until`,
      [req.user.org,brand,model,plate.toUpperCase(),mileage,status,nextService,insuranceUntil]);
    res.status(201).json(rows[0]);
  } catch(e) {
    if(e.code==="23505") return res.status(409).json({error:"plate_exists"});
    res.status(500).json({error:"server_error"});
  }
});

app.patch("/api/v1/vehicles/:id", auth, async (req,res) => {
  const allowed=["brand","model","plate","mileage","status","next_service","insurance_until"];
  const fields=Object.entries(req.body||{}).filter(([k])=>allowed.includes(k));
  if(!fields.length) return res.status(400).json({error:"no_changes"});
  const set=fields.map(([k],i)=>`${k}=$${i+1}`).join(",");
  const values=fields.map(([,v])=>v);
  values.push(req.params.id,req.user.org);
  const {rows}=await pool.query(
    `update vehicles set ${set} where id=$${values.length-1} and organization_id=$${values.length}
     returning id,brand,model,plate,mileage,status,next_service,insurance_until`, values);
  if(!rows[0]) return res.status(404).json({error:"not_found"});
  res.json(rows[0]);
});

app.get("/api/v1/employees", auth, async (req,res) => {
  const {rows}=await pool.query(
    "select id,name,email,role,created_at from employees where organization_id=$1 order by created_at desc",[req.user.org]);
  res.json(rows);
});

app.post("/api/v1/employees", auth, requireOwner, async (req,res) => {
  const {name,email,role="observer"}=req.body||{};
  if(!name) return res.status(400).json({error:"name required"});
  const {rows}=await pool.query(
    "insert into employees(organization_id,name,email,role) values($1,$2,$3,$4) returning *",
    [req.user.org,name,email||null,role]);
  res.status(201).json(rows[0]);
});

app.post("/api/v1/inspections", auth, async (req,res) => {
  const {vehicleId,mileage,passed=true,comment=""}=req.body||{};
  const own=await pool.query("select id from vehicles where id=$1 and organization_id=$2",[vehicleId,req.user.org]);
  if(!own.rows[0]) return res.status(404).json({error:"vehicle_not_found"});
  const client=await pool.connect();
  try {
    await client.query("begin");
    const r=await client.query(
      "insert into inspections(vehicle_id,employee_id,mileage,passed,comment) values($1,$2,$3,$4,$5) returning *",
      [vehicleId,req.user.sub,mileage,passed,comment]);
    await client.query("update vehicles set mileage=greatest(mileage,$1) where id=$2",[mileage,vehicleId]);
    await client.query("commit");
    res.status(201).json(r.rows[0]);
  } catch { await client.query("rollback"); res.status(500).json({error:"server_error"}); }
  finally { client.release(); }
});

app.post("/api/v1/expenses", auth, async (req,res) => {
  const {vehicleId,amount,category,comment=""}=req.body||{};
  const own=await pool.query("select id from vehicles where id=$1 and organization_id=$2",[vehicleId,req.user.org]);
  if(!own.rows[0]) return res.status(404).json({error:"vehicle_not_found"});
  const {rows}=await pool.query(
    "insert into expenses(vehicle_id,amount,category,comment) values($1,$2,$3,$4) returning *",
    [vehicleId,amount,category,comment]);
  res.status(201).json(rows[0]);
});

app.delete("/api/v1/account", auth, async (req,res) => {
  const client=await pool.connect();
  try {
    await client.query("begin");
    await client.query("delete from organizations where id=$1",[req.user.org]);
    await client.query("commit");
    res.status(204).end();
  } catch { await client.query("rollback"); res.status(500).json({error:"server_error"}); }
  finally { client.release(); }
});

// App Store Server Notifications V2.
// Configure APPLE_ROOT_CA_PATHS with Apple root certificates before production.
// The Apple-supplied library verifies the signed JWS payload.
let appleVerifier = null;
let appleSandboxVerifier = null;
try {
  const paths=(process.env.APPLE_ROOT_CA_PATHS||"").split(",").filter(Boolean);
  if(paths.length && process.env.APPLE_APPLE_ID) {
    const roots = paths.map(p=>fs.readFileSync(p));
    const bundle = process.env.APPLE_BUNDLE_ID || "com.realmotion12.parkcontrol";
    const appId = Number(process.env.APPLE_APPLE_ID);
    appleVerifier = new SignedDataVerifier(roots, true, Environment.PRODUCTION, bundle, appId);
    appleSandboxVerifier = new SignedDataVerifier(roots, true, Environment.SANDBOX, bundle, undefined);
  }
} catch(e) { console.error("Apple verifier init failed:", e.message); }

async function handleAppleNotification(req,res,verifier) {
  if(!verifier) return res.status(503).json({error:"apple_verifier_not_configured"});
  try {
    const notification = await verifier.verifyAndDecodeNotification(req.body.signedPayload);
    const uuid = notification.notificationUUID;
    const exists = await pool.query("select 1 from apple_notifications where notification_uuid=$1",[uuid]);
    if(exists.rows[0]) return res.status(200).json({ok:true});

    const data = notification.data || {};
    const transaction = data.signedTransactionInfo
      ? await verifier.verifyAndDecodeTransaction(data.signedTransactionInfo)
      : null;
    const type = notification.notificationType || "UNKNOWN";
    const subtype = notification.subtype || null;

    await pool.query(
      `insert into apple_notifications(notification_uuid,notification_type,subtype,environment,payload)
       values($1,$2,$3,$4,$5)`,
      [uuid,type,subtype,transaction?.environment || data.environment || null,JSON.stringify(notification)]);

    if (transaction?.productId === PRODUCT_ID && transaction.appAccountToken) {
      const user = await pool.query("select id,organization_id from users where id=$1", [transaction.appAccountToken]);
      if (user.rows[0]) {
        const expiry = transaction.expiresDate ? new Date(transaction.expiresDate) : null;
        let status = "active";
        if (["EXPIRED","GRACE_PERIOD_EXPIRED","REVOKE","REFUND"].includes(type)) status = "inactive";
        if (transaction.revocationDate) status = "inactive";
        await pool.query(
          `insert into subscriptions(user_id,organization_id,product_id,original_transaction_id,transaction_id,expires_at,status,environment)
           values($1,$2,$3,$4,$5,$6,$7,$8)
           on conflict(product_id,original_transaction_id) do update set
             transaction_id=excluded.transaction_id,expires_at=excluded.expires_at,status=excluded.status,
             environment=excluded.environment,updated_at=now()`,
          [user.rows[0].id,user.rows[0].organization_id,transaction.productId,
           transaction.originalTransactionId || transaction.transactionId,transaction.transactionId,expiry,status,transaction.environment]);
      }
    }
    res.status(200).json({ok:true});
  } catch(e) {
    console.error("Apple notification error:",e.message);
    res.status(400).json({error:"invalid_notification"});
  }
}

app.post("/api/v1/apple/notifications", (req,res)=>handleAppleNotification(req,res,appleVerifier));
app.post("/api/v1/apple/notifications/sandbox", (req,res)=>handleAppleNotification(req,res,appleSandboxVerifier));

app.listen(process.env.PORT||8080,()=>console.log("ParkControl API listening"));
