import Foundation

struct Vehicle: Identifiable {
    let id = UUID()
    var brand: String
    var model: String
    var plate: String
    var mileage: Int
    var status: Status
    var nextService: String
    var insurance: String
    var serverID: String? = nil

    enum Status: String {
        case line = "На линии"
        case repair = "В ремонте"
        case idle = "Простой"
    }
}

let demoVehicles = [
    Vehicle(brand: "Toyota", model: "Camry", plate: "А123АА", mileage: 184_250, status: .line, nextService: "2 150 км", insurance: "12.11.2026"),
    Vehicle(brand: "Hyundai", model: "Elantra", plate: "В456ВС", mileage: 156_820, status: .line, nextService: "4 800 км", insurance: "03.12.2026"),
    Vehicle(brand: "Kia", model: "K5", plate: "С789СС", mileage: 201_430, status: .repair, nextService: "После ремонта", insurance: "19.10.2026"),
    Vehicle(brand: "Chery", model: "Arrizo 8", plate: "Е111ЕЕ", mileage: 98_640, status: .idle, nextService: "6 360 км", insurance: "27.01.2027")
]