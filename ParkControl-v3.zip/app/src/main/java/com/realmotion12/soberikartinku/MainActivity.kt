package com.realmotion12.soberikartinku

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.max

class MainActivity : Activity() {
    private val yellow = Color.rgb(255,204,0)
    private val bg = Color.rgb(11,11,11)
    private val card = Color.rgb(25,25,25)
    private val text = Color.WHITE
    private val muted = Color.rgb(160,160,160)
    private val prefs by lazy { getSharedPreferences("park", MODE_PRIVATE) }
    private var cars = mutableListOf<Car>()
    private var inspections = mutableListOf<Inspection>()
    private var inspectionInterval = 7
    private var currentSection = "Главная"
    private var cameraStep = 0
    private var cameraCar: Car? = null
    private val photoLabels = listOf("Спереди", "Слева", "Справа", "Сзади", "Багажник", "Одометр")
    private val checklist = listOf("СТС", "Страховка", "Диагностическая карта", "Шашка", "Салон чистый", "Аптечка", "Огнетушитель", "Знак аварийной остановки", "Запасное колесо", "Домкрат", "Ремень безопасности", "Фары", "Шины")

    data class Car(var brand:String, var model:String, var plate:String, var mileage:Int, var status:String="На линии", var nextInspection:Long=System.currentTimeMillis())
    data class Inspection(val plate:String, val mileage:Int, val time:Long, val employee:String, val result:String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        showLoginIfNeeded()
    }

    private fun showLoginIfNeeded(){
        if(prefs.getBoolean("logged", false)) showMain() else login()
    }

    private fun login(){
        val root=base(); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(28,40,28,40)}
        box.addView(label("ПаркКонтроль",32f,text), lp(-1,-2)); box.addView(label("Управление автопарком",16f,muted), lp(-1,-2))
        val e=EditText(this).apply{hint="Email или телефон";setTextColor(text);setHintTextColor(muted);setSingleLine()}; box.addView(e, lp(-1,60))
        val p=EditText(this).apply{hint="Пароль";setTextColor(text);setHintTextColor(muted);inputType=129;setSingleLine()}; box.addView(p, lp(-1,60))
        val b=button("Войти",yellow,Color.BLACK){prefs.edit().putBoolean("logged",true).putString("user",e.text.toString().ifBlank{"Администратор"}).apply();showMain()}; box.addView(b,lp(-1,58))
        box.addView(label("Демо-вход: локальный администратор",13f,muted),lp(-1,-2)); root.addView(box,lp(-1,-1));setContentView(root)
    }

    private fun showMain(){ dashboard() }
    private fun dashboard(){ currentSection="Главная"; val root=base(); val scroll=ScrollView(this); val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,110)}
        col.addView(header("ПаркКонтроль","Сегодня · контроль парка"),lp(-1,-2))
        val due=cars.count{it.nextInspection<=System.currentTimeMillis()}; val repair=cars.count{it.status=="В ремонте"}; val line=cars.count{it.status=="На линии"}
        col.addView(card("Автомобили","${cars.size} всего  •  $line на линии  •  $repair в ремонте", "🚕"),lp(-1,110))
        col.addView(card("Осмотры сегодня","$due автомобилей требуют осмотра", "🔧") { inspections() },lp(-1,110))
        col.addView(card("Центр задач","ОСАГО · ТО · ремонты · осмотры", "⚡"),lp(-1,110))
        col.addView(label("Быстрый доступ",18f,text),lp(-1,-2))
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}; row.addView(card("Парк","Автомобили","🚗"){carsScreen()},lp(0,120,1f));row.addView(card("Осмотр","Начать","📷"){inspections()},lp(0,120,1f));col.addView(row,lp(-1,130))
        scroll.addView(col);root.addView(scroll,lp(-1,0,1f));root.addView(nav(),lp(-1,70));setContentView(root)
    }

    private fun carsScreen(){ currentSection="Парк"; val root=base(); val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,90)};col.addView(header("Автомобили","${cars.size} в парке"),lp(-1,-2));col.addView(button("＋ Добавить автомобиль",yellow,Color.BLACK){editCar(null)},lp(-1,54));col.addView(button("📥 Импорт Excel (.xlsx)",card,text){pickExcel()},lp(-1,54));
        if(cars.isEmpty()) col.addView(empty("Парк пока пуст\nДобавьте автомобиль или импортируйте Excel"),lp(-1,220))
        cars.forEach{c->col.addView(carRow(c),lp(-1,110))}; val s=ScrollView(this);s.addView(col);root.addView(s,lp(-1,0,1f));root.addView(nav(),lp(-1,70));setContentView(root)}

    private fun carRow(c:Car):View{ val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,14,18,14);background=round(card,20)};val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};top.addView(label("${c.brand} ${c.model}",19f,text),lp(0,-2,1f));top.addView(label(c.status,13f,yellow),lp(-2,-2));l.addView(top,lp(-1,38));l.addView(label("${c.plate}  ·  ${c.mileage} км",14f,muted),lp(-1,28));l.setOnClickListener{carDetail(c)};return l}

    private fun carDetail(c:Car){ val root=base();val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,90)};col.addView(header("${c.brand} ${c.model}",c.plate),lp(-1,-2));col.addView(card("Пробег","${c.mileage} км","📏"),lp(-1,95));col.addView(card("Статус",c.status,"●"),lp(-1,95));col.addView(card("Следующий осмотр",dateText(c.nextInspection),"🔧"),lp(-1,95));col.addView(button("📷 Провести осмотр",yellow,Color.BLACK){startInspection(c)},lp(-1,58));col.addView(button("✏ Редактировать",card,text){editCar(c)},lp(-1,58));col.addView(button("← Назад",card,text){carsScreen()},lp(-1,58));val s=ScrollView(this);s.addView(col);root.addView(s,lp(-1,-1));setContentView(root)}

    private fun editCar(existing:Car?){ val root=base();val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,40)};col.addView(header(if(existing==null)"Новый автомобиль" else "Редактирование","Данные автомобиля"),lp(-1,-2));val fields=listOf("Марка","Модель","Госномер","Пробег");val inputs=fields.map{f->EditText(this).apply{hint=f;setTextColor(text);setHintTextColor(muted);setSingleLine();if(f=="Пробег")inputType=2}};existing?.let{inputs[0].setText(it.brand);inputs[1].setText(it.model);inputs[2].setText(it.plate);inputs[3].setText(it.mileage.toString())};inputs.forEach{col.addView(it,lp(-1,58))};col.addView(button("Сохранить",yellow,Color.BLACK){val c=existing?:Car("","","",0);c.brand=inputs[0].text.toString();c.model=inputs[1].text.toString();c.plate=inputs[2].text.toString();c.mileage=inputs[3].text.toString().toIntOrNull()?:0;if(existing==null)cars.add(c);save();carsScreen()},lp(-1,58));col.addView(button("Отмена",card,text){carsScreen()},lp(-1,58));root.addView(ScrollView(this).apply{addView(col)},lp(-1,-1));setContentView(root)}

    private fun inspections(){currentSection="Осмотры";val root=base();val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,100)};col.addView(header("Осмотры","Интервал: каждые $inspectionInterval дней"),lp(-1,-2));val due=cars.filter{it.nextInspection<=System.currentTimeMillis()};col.addView(card("Сегодня","${due.size} автомобилей","🔧"),lp(-1,100));if(due.isEmpty())col.addView(empty("Все осмотры выполнены\nНа сегодня задач нет"),lp(-1,220));due.forEach{c->col.addView(carRow(c),lp(-1,110))};col.addView(button("⚙ Настройка интервала",card,text){inspectionSettings()},lp(-1,58));root.addView(ScrollView(this).apply{addView(col)},lp(-1,0,1f));root.addView(nav(),lp(-1,70));setContentView(root)}

    private fun inspectionSettings(){ val opts=arrayOf("1 день","7 дней","14 дней","30 дней");AlertDialog.Builder(this).setTitle("Период осмотра").setSingleChoiceItems(opts,opts.indexOf("$inspectionInterval дней")){d,w->inspectionInterval=listOf(1,7,14,30)[w];prefs.edit().putInt("interval",inspectionInterval).apply();d.dismiss();inspections()}.show() }

    private fun startInspection(c:Car){cameraCar=c;cameraStep=0;inspectionMileage(c)}
    private fun inspectionMileage(c:Car){val e=EditText(this).apply{hint="Показание одометра";inputType=2;setText(c.mileage.toString())};AlertDialog.Builder(this).setTitle("Шаг 1 · Текущий пробег").setMessage("Укажите фактический пробег автомобиля").setView(e).setPositiveButton("Продолжить"){_,_->val m=e.text.toString().toIntOrNull();if(m==null){toast("Введите пробег");return@setPositiveButton};if(m<c.mileage){AlertDialog.Builder(this).setTitle("Пробег меньше предыдущего").setMessage("Предыдущий: ${c.mileage} км\nТекущий: $m км\nПодтвердить?").setNegativeButton("Изменить",null).setPositiveButton("Подтвердить"){_,_->c.mileage=m;cameraStep=0;nextPhoto(c)}.show()}else{c.mileage=m;cameraStep=0;nextPhoto(c)}}.setNegativeButton("Отмена",null).show()}
    private fun nextPhoto(c:Car){if(cameraStep<photoLabels.size){val label=photoLabels[cameraStep];AlertDialog.Builder(this).setTitle("Фото · $label").setMessage("Сделайте фото: $label").setPositiveButton("Открыть камеру"){_,_->openCamera()}.setNegativeButton("Пропустить"){_,_->cameraStep++;nextPhoto(c)}.show()}else checklistScreen(c)}
    private fun openCamera(){if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.CAMERA),55);return};startActivityForResult(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE),101)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==101 && resultCode==RESULT_OK){toast("Фото принято");cameraStep++;cameraCar?.let{nextPhoto(it)}} else if(requestCode==202 && resultCode==RESULT_OK && data?.data!=null){parseXlsx(data.data!!)}}
    private fun checklistScreen(c:Car){val root=base();val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,80)};col.addView(header("Чек-лист","${c.brand} ${c.model} · ${c.plate}"),lp(-1,-2));val checks=mutableListOf<CheckBox>();checklist.forEach{n->checks.add(CheckBox(this).apply{text=n;setTextColor(text);textSize=16f;buttonTintList=android.content.res.ColorStateList.valueOf(yellow);col.addView(this,lp(-1,52))})};val damage=EditText(this).apply{hint="Повреждения / комментарий";setTextColor(text);setHintTextColor(muted);minLines=3;gravity=Gravity.TOP};col.addView(damage,lp(-1,100));col.addView(button("✓ Завершить осмотр",yellow,Color.BLACK){finishInspection(c,checks,damage.text.toString())},lp(-1,58));root.addView(ScrollView(this).apply{addView(col)},lp(-1,-1));setContentView(root)}
    private fun finishInspection(c:Car,checks:List<CheckBox>,comment:String){val bad=checks.filter{!it.isChecked}.map{it.text}.joinToString(", ");val result=if(bad.isBlank())"Без замечаний" else "Нет: $bad";c.nextInspection=System.currentTimeMillis()+inspectionInterval*86400000L;inspections.add(Inspection(c.plate,c.mileage,System.currentTimeMillis(),prefs.getString("user","Администратор")?:"Администратор",result+if(comment.isNotBlank())" · $comment"));save();toast("Осмотр завершён");carDetail(c)}

    private fun more(){currentSection="Ещё";val root=base();val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,100)};col.addView(header("Ещё","Настройки и управление"),lp(-1,-2));listOf("👥 Сотрудники и права","🔔 Уведомления","🔄 Интеграция с 1С","⚙ Настройки осмотров","📜 История осмотров","🚪 Выйти").forEach{t->col.addView(button(t,card,text){when{t.startsWith("👥")->employees();t.startsWith("🔔")->notifications();t.startsWith("🔄")->oneC();t.startsWith("⚙")->inspectionSettings();t.startsWith("📜")->history();t.startsWith("🚪")-> {prefs.edit().putBoolean("logged",false).apply();login()}}}},lp(-1,58))};root.addView(ScrollView(this).apply{addView(col)},lp(-1,0,1f));root.addView(nav(),lp(-1,70));setContentView(root)}

    private fun employees(){AlertDialog.Builder(this).setTitle("Сотрудники и права").setMessage("В MVP доступен локальный администратор.\n\nСледующий серверный слой позволит создавать сотрудников, роли и точечные разрешения: автомобили, осмотры, ремонты, расходы, Excel и 1С.").setPositiveButton("ОК",null).show()}
    private fun notifications(){AlertDialog.Builder(this).setTitle("Уведомления").setMultiChoiceItems(arrayOf("Осмотры сегодня","Просроченные осмотры","ТО","ОСАГО","Ремонты"),null,null).setPositiveButton("Сохранить",null).show()}
    private fun oneC(){val url=EditText(this).apply{hint="URL REST 1С";setText(prefs.getString("1c",""));setTextColor(text);setHintTextColor(muted)};AlertDialog.Builder(this).setTitle("Интеграция с 1С").setMessage("Укажите адрес опубликованного REST-интерфейса вашей базы 1С.").setView(url).setPositiveButton("Сохранить"){_,_->prefs.edit().putString("1c",url.text.toString()).apply();toast("Настройки 1С сохранены")}.setNegativeButton("Отмена",null).show()}
    private fun history(){val root=base();val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,90)};col.addView(header("История осмотров","${inspections.size} записей"),lp(-1,-2));inspections.asReversed().forEach{i->col.addView(card(i.plate,"${i.employee} · ${dateText(i.time)}\nПробег ${i.mileage} км\n${i.result}","📋"),lp(-1,140))};root.addView(ScrollView(this).apply{addView(col)},lp(-1,-1));setContentView(root)}

    private fun pickExcel(){val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,202)}
    private fun parseXlsx(uri:android.net.Uri){try{val input=contentResolver.openInputStream(uri)?:return;val temp=File(cacheDir,"import.xlsx");input.use{a->temp.outputStream().use{b->a.copyTo(b)}};val map=mutableMapOf<String,String>();ZipInputStream(FileInputStream(temp)).use{z->while(true){val e=z.nextEntry?:break;if(e.name=="xl/sharedStrings.xml"){val xml=DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(z);val ns=xml.getElementsByTagName("t");for(k in 0 until ns.length)map[k.toString()]=ns.item(k).textContent}}};toast("Excel выбран. Для полноценного импорта ожидается шаблон ParkControl: Марка, Модель, Госномер, Пробег, Статус.")}catch(e:Exception){toast("Не удалось прочитать Excel")}}
    override fun onResume(){super.onResume();inspectionInterval=prefs.getInt("interval",7)}
    override fun onActivityResultOld(requestCode:Int,resultCode:Int,data:Intent?){ }

    private fun base():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);systemUiVisibility=0}
    private fun nav():LinearLayout{val n=LinearLayout(this).apply{setPadding(6,6,6,6);setBackgroundColor(Color.rgb(18,18,18));gravity=Gravity.CENTER};n.addView(navBtn("Главная","⌂"){dashboard()},lp(0,-1,1f));n.addView(navBtn("Парк","🚗"){carsScreen()},lp(0,-1,1f));n.addView(navBtn("Осмотры","🔧"){inspections()},lp(0,-1,1f));n.addView(navBtn("Ещё","•••"){more()},lp(0,-1,1f));return n}
    private fun navBtn(t:String,ic:String,click:()->Unit)=TextView(this).apply{text="$ic\n$t";gravity=Gravity.CENTER;textSize=11f;setTextColor(if(currentSection==t)yellow else muted);setOnClickListener{click()}}
    private fun header(a:String,b:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(label(a,30f,text),lp(-1,44));addView(label(b,14f,muted),lp(-1,30));}
    private fun card(a:String,b:String,ic:String,on:()->Unit={})=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,15,18,15);background=round(card,20);setOnClickListener{on()};addView(label("$ic  $a",16f,yellow),lp(-1,32));addView(label(b,15f,muted),lp(-1,45))}
    private fun button(t:String,bgColor:Int,fg:Int,on:()->Unit)=TextView(this).apply{text=t;gravity=Gravity.CENTER;textSize=15f;setTextColor(fg);background=round(bgColor,16);setOnClickListener{on()};setPadding(10,0,10,0)}
    private fun label(t:String,s:Float,c:Int)=TextView(this).apply{text=t;textSize=s;setTextColor(c);setPadding(0,0,0,0)}
    private fun empty(t:String)=TextView(this).apply{text=t;gravity=Gravity.CENTER;textSize=17f;setTextColor(muted)}
    private fun lp(w:Int,h:Int,weight:Float=0f)=LinearLayout.LayoutParams(w,h,weight).apply{setMargins(0,7,0,7)}
    private fun round(c:Int,r:Float)=GradientDrawable().apply{setColor(c);cornerRadius=r}
    private fun dateText(ms:Long)=java.text.SimpleDateFormat("dd.MM.yyyy HH:mm").format(java.util.Date(ms))
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
    private fun save(){prefs.edit().putString("cars",cars.joinToString(";;"){listOf(it.brand,it.model,it.plate,it.mileage,it.status,it.nextInspection).joinToString("|")}).apply()}
    private fun load(){inspectionInterval=prefs.getInt("interval",7);val raw=prefs.getString("cars","")?:"";if(raw.isNotBlank())raw.split(";;").forEach{p->val x=p.split("|");if(x.size>=6)cars.add(Car(x[0],x[1],x[2],x[3].toIntOrNull()?:0,x[4],x[5].toLongOrNull()?:System.currentTimeMillis()))}}
}
