# ParkControl — App Store release checklist

## Product
- Bundle ID: `com.realmotion12.parkcontrol`
- Minimum iOS: 17
- Subscription: `com.realmotion12.parkcontrol.pro.monthly`
- Intended price: 5,000 RUB/month (configure the actual storefront price in App Store Connect)
- App name: ПаркКонтроль
- Category: Business

## Already in project
- Premium fleet dashboard
- Vehicle list/search
- Vehicle detail
- Add vehicle
- Inspections area
- Expenses/history UI
- Employees/settings navigation
- Account login/register shell
- Account deletion entry
- StoreKit 2 subscription purchase/restore/manage
- App icon asset
- PrivacyInfo.xcprivacy
- Production backend starter

## Before submission
1. Create the App Store Connect app using the exact bundle ID.
2. Create the subscription group and monthly subscription with the exact product ID.
3. Configure the Russian/storefront pricing.
4. Add Privacy Policy URL and Terms of Use URL.
5. Complete App Privacy answers in App Store Connect.
6. Configure App Store Server Notifications V2 for production and sandbox.
7. Deploy backend with HTTPS and PostgreSQL.
8. Configure Apple root certificates and App Store API credentials on the server.
9. Connect the iOS API base URL to the deployed backend.
10. Replace demo auth calls with the production API calls in `SessionStore`.
11. Test registration/login/logout/account deletion.
12. Test subscription purchase, restore, renewal, cancellation, billing retry, refund.
13. Test with TestFlight and sandbox accounts.
14. Archive Release in Xcode and upload to App Store Connect.
15. Submit for review.

Apple requires account deletion for apps that support account creation, and Apple recommends
server-side App Store Server Notifications V2 for subscription lifecycle changes.
