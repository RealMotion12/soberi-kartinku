# ParkControl

Commercial iOS SaaS foundation for taxi fleets.

iOS 17+, SwiftUI, StoreKit 2, multi-tenant backend starter, PostgreSQL.

See `RELEASE.md` for the launch checklist and `backend/README.md` for server deployment.
