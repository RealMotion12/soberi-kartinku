package com.realmotion12.soberikartinku

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val bg = Color.rgb(18, 18, 18)
    private val card = Color.rgb(30, 30, 30)
    private val yellow = Color.rgb(255, 204, 0)
    private val white = Color.WHITE
    private val muted = Color.rgb(165, 165, 165)
    private val prefs by lazy { getSharedPreferences("park_control", MODE_PRIVATE) }
    private var inspectionStep = 0
    private var inspectionMileage = ""
    private var currentCar = ""
    private val photoSteps = arrayOf("Спереди", "Слева", "Справа", "Сзади", "Багажник")

    data class Car(val brand:String, val model:String, val plate:String, var mileage:Int, var status:String = "На линии")

    private val cars = mutableListOf(
        Car("Toyota", "Camry", "А123АА", 184250),
        Car("Kia", "Rio", "В456ВВ", 126800),
        Car("Hyundai", "Solaris", "С789СС", 97200),
        Car("Lada", "Vesta", "Е111ЕЕ", 201450, "В ремонте")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
        requestNotificationPermission()
    }

    private fun baseRoot(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        setPadding(dp(18), dp(18), dp(18), dp(10))
    }

    private fun title(text:String, size:Float=28f): TextView = TextView(this).apply {
        this.text=text; textSize=size; setTextColor(white); typeface=Typeface.DEFAULT_BOLD
        setPadding(0,0,0,dp(10))
    }

    private fun label(text:String): TextView = TextView(this).apply {
        this.text=text; textSize=14f; setTextColor(muted); setPadding(0,dp(6),0,dp(4))
    }

    private fun button(text:String, action:()->Unit): Button = Button(this).apply {
        this.text=text; textSize=14f; isAllCaps=false; setTextColor(Color.BLACK)
        setBackgroundColor(yellow); setOnClickListener { action() }
    }

    private fun cardView(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14)); setBackgroundColor(card)
    }

    private fun setScreen(root:View) { setContentView(root) }

    private fun showDashboard() {
        val root=baseRoot(); root.addView(title("ПаркКонтроль")); root.addView(label("Управление автопарком"))
        val stats=cardView(); stats.addView(label("ПАРК")); stats.addView(title("${cars.size} автомобилей",25f))
        val row=LinearLayout(this); row.addView(stat("На линии","${cars.count { it.status == "На линии" }}"), LinearLayout.LayoutParams(0,dp(70),1f)); row.addView(stat("Ремонт","${cars.count { it.status == "В ремонте" }}"), LinearLayout.LayoutParams(0,dp(70),1f)); row.addView(stat("Осмотры","15"), LinearLayout.LayoutParams(0,dp(70),1f)); stats.addView(row)
        root.addView(stats, LinearLayout.LayoutParams(-1,dp(190)))
        root.addView(label("БЫСТРЫЕ ДЕЙСТВИЯ"))
        root.addView(button("🚗 Автомобили") { showCars() }, LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("🔧 Осмотры — сегодня 15") { showInspections() }, LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("👥 Сотрудники и права") { showEmployees() }, LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("⚙ Настройки и интеграции") { showSettings() }, LinearLayout.LayoutParams(-1,dp(55)))
        setScreen(root)
    }

    private fun stat(name:String,value:String)=TextView(this).apply{ text="$name\n$value"; textSize=14f; setTextColor(white); gravity=Gravity.CENTER; setPadding(4,4,4,4) }

    private fun showCars() {
        val root=baseRoot(); root.addView(title("Автомобили")); root.addView(label("${cars.size} автомобилей в парке"))
        cars.forEach { c ->
            val v=cardView(); v.addView(TextView(this).apply{ text="${c.brand} ${c.model}"; textSize=19f; setTextColor(white); typeface=Typeface.DEFAULT_BOLD })
            v.addView(label("${c.plate}  •  ${c.mileage} км  •  ${c.status}"))
            v.addView(button("Открыть") { showCar(c) })
            root.addView(v, LinearLayout.LayoutParams(-1,dp(125)).apply{setMargins(0,0,0,dp(10))})
        }
        root.addView(button("← Назад") { showDashboard() })
        setScreen(root)
    }

    private fun showCar(car:Car) {
        val root=baseRoot(); root.addView(title("${car.brand} ${car.model}")); root.addView(label(car.plate))
        val c=cardView(); c.addView(label("СТАТУС")); c.addView(TextView(this).apply{ text=car.status; textSize=22f; setTextColor(yellow) }); c.addView(label("Пробег: ${car.mileage} км")); root.addView(c,LinearLayout.LayoutParams(-1,dp(150)))
        root.addView(button("🔧 Провести осмотр") { beginInspection(car) }, LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("🛠 Ремонт") { toast("Раздел ремонта подготовлен") }, LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("📄 Документы") { toast("Документы автомобиля") }, LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("💰 Расходы") { toast("Расходы автомобиля") }, LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("← Назад") { showCars() })
        setScreen(root)
    }

    private fun showInspections() {
        val root=baseRoot(); root.addView(title("Осмотры")); root.addView(label("СЕГОДНЯ"))
        val info=cardView(); info.addView(TextView(this).apply{ text="15 осмотров"; textSize=24f; setTextColor(yellow); typeface=Typeface.DEFAULT_BOLD }); info.addView(label("12 на сегодня  •  3 просрочено")); root.addView(info,LinearLayout.LayoutParams(-1,dp(120)))
        cars.forEach { c ->
            root.addView(button("${c.brand} ${c.model}  •  ${c.plate}") { beginInspection(c) },LinearLayout.LayoutParams(-1,dp(55)).apply{setMargins(0,0,0,dp(7))})
        }
        root.addView(button("← Назад") { showDashboard() }); setScreen(root)
    }

    private fun beginInspection(car:Car) {
        currentCar=car.plate
        val input=EditText(this).apply{ hint="Например, ${car.mileage}"; inputType=2; setTextColor(white); setHintTextColor(muted) }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(10),dp(20),0);addView(label("ТЕКУЩИЙ ПРОБЕГ — ОБЯЗАТЕЛЬНО"));addView(input)}
        AlertDialog.Builder(this).setTitle("Начало осмотра").setMessage("${car.brand} ${car.model} • ${car.plate}\nПредыдущий пробег: ${car.mileage} км").setView(box).setPositiveButton("Продолжить"){_,_->
            val m=input.text.toString().toIntOrNull()
            if(m==null){toast("Введите пробег");return@setPositiveButton}
            if(m<car.mileage){toast("Пробег не может быть меньше предыдущего");return@setPositiveButton}
            car.mileage=m; inspectionMileage=m.toString(); inspectionStep=0; requestCamera(); startPhotoStep()
        }.setNegativeButton("Отмена",null).show()
    }

    private fun startPhotoStep(){
        if(inspectionStep<photoSteps.size){
            AlertDialog.Builder(this).setTitle("Фото ${inspectionStep+1} из ${photoSteps.size}").setMessage("Сфотографируйте автомобиль: ${photoSteps[inspectionStep]}").setPositiveButton("📷 Камера"){_,_->openCamera()}.setNegativeButton("Пропустить",null).show()
        } else { showChecklist() }
    }

    private fun openCamera(){ startActivityForResult(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE),100) }
    private fun requestCamera(){ if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.CAMERA),10) }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==100){ if(resultCode==RESULT_OK) toast("Фото ${photoSteps[inspectionStep]} сохранено"); else toast("Фото отменено"); inspectionStep++; startPhotoStep() } }

    private fun showChecklist(){
        val root=baseRoot(); root.addView(title("Чек-лист осмотра")); root.addView(label("${currentCar}  •  пробег $inspectionMileage км"))
        val items=arrayOf("СТС","Страховка","Диагностическая карта","Шашка","Салон чистый","Аптечка","Огнетушитель","Знак аварийной остановки","Запасное колесо","Домкрат","Ремень безопасности","Фары","Шины")
        items.forEach{ text -> val cb=CheckBox(this).apply{text="$text — есть / исправно";setTextColor(white);textSize=16f};root.addView(cb,LinearLayout.LayoutParams(-1,dp(48))) }
        root.addView(button("Есть повреждения кузова") { toast("Открыть схему кузова") },LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("✓ Завершить осмотр") { toast("Осмотр сохранён"); showInspections() },LinearLayout.LayoutParams(-1,dp(55)))
        setScreen(root)
    }

    private fun showEmployees(){
        val root=baseRoot();root.addView(title("Сотрудники"));root.addView(label("Права доступа назначает администратор"))
        val users=arrayOf("Администратор","Механик — Иван","Механик — Алексей","Наблюдатель")
        users.forEach{u-> val v=cardView();v.addView(TextView(this).apply{text=u;textSize=18f;setTextColor(white);typeface=Typeface.DEFAULT_BOLD});v.addView(label(if(u.contains("Механик"))"Осмотры • автомобили • фото" else if(u.contains("Наблюдатель"))"Только просмотр" else "Полный доступ"));root.addView(v,LinearLayout.LayoutParams(-1,dp(100)).apply{setMargins(0,0,0,dp(8))})}
        root.addView(button("+ Добавить сотрудника") { toast("Создание сотрудника") });root.addView(button("← Назад"){showDashboard()});setScreen(root)
    }

    private fun showSettings(){
        val root=baseRoot();root.addView(title("Настройки"));root.addView(label("ОСМОТРЫ"));
        val spinner=Spinner(this);spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Каждые 1 день","Каждые 7 дней","Каждые 14 дней","Каждые 30 дней"));root.addView(spinner,LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(label("УВЕДОМЛЕНИЯ"));val n=Switch(this).apply{text="Напоминать механику об осмотрах";setTextColor(white);isChecked=prefs.getBoolean("notify",true);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("notify",v).apply()}};root.addView(n,LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(label("ИНТЕГРАЦИЯ 1С"));val url=EditText(this).apply{hint="URL REST-интерфейса 1С";setText(prefs.getString("onec_url",""));setTextColor(white);setHintTextColor(muted)};root.addView(url,LinearLayout.LayoutParams(-1,dp(55)));root.addView(button("Сохранить подключение 1С"){prefs.edit().putString("onec_url",url.text.toString()).apply();toast("Настройки 1С сохранены")},LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(label("EXCEL"));root.addView(button("📥 Импорт парка из Excel"){toast("Импорт Excel будет подключён следующим шагом")},LinearLayout.LayoutParams(-1,dp(55)))
        root.addView(button("← Назад"){showDashboard()});setScreen(root)
    }

    private fun requestNotificationPermission(){ if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),11) }
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}
