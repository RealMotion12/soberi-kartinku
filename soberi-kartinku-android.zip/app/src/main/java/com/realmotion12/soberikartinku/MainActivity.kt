package com.realmotion12.soberikartinku

import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.random.Random

class MainActivity : android.app.Activity() {
    private var n = 3
    private var tiles = mutableListOf<Int>()
    private var selected = -1
    private var moves = 0
    private lateinit var grid: GridLayout
    private lateinit var movesText: TextView
    private lateinit var message: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        startGame()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(16,24,39))
        }

        val title = TextView(this).apply {
            text = "🧩 Собери картинку"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0,0,0,6)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val sub = TextView(this).apply {
            text = "Собери изображение из кусочков"
            textSize = 15f
            setTextColor(Color.rgb(159,176,199))
            gravity = Gravity.CENTER
            setPadding(0,0,0,18)
        }
        root.addView(sub, LinearLayout.LayoutParams(-1,-2))

        val bar = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("3 × 3","4 × 4","5 × 5"))
        spinner.setSelection(0)
        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val newN = pos + 3
                if (newN != n) { n=newN; startGame() }
            }
        }
        bar.addView(spinner, LinearLayout.LayoutParams(0,-2,1f))
        movesText = TextView(this).apply { text="Ходы: 0"; textSize=16f; setTextColor(Color.WHITE); gravity=Gravity.CENTER }
        bar.addView(movesText, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(bar, LinearLayout.LayoutParams(-1,-2))

        grid = GridLayout(this).apply { useDefaultMargins=false; alignmentMode=GridLayout.ALIGN_BOUNDS }
        val gridLp = LinearLayout.LayoutParams(-1,0,1f); gridLp.setMargins(0,18,0,12)
        root.addView(grid, gridLp)

        message = TextView(this).apply { textSize=18f; setTextColor(Color.rgb(255,209,102)); gravity=Gravity.CENTER }
        root.addView(message, LinearLayout.LayoutParams(-1,40))

        val buttons = LinearLayout(this).apply { gravity=Gravity.CENTER }
        val shuffle = Button(this).apply { text="🔀 Перемешать"; setOnClickListener { startGame() } }
        val fresh = Button(this).apply { text="▶ Новая игра"; setOnClickListener { startGame() } }
        buttons.addView(shuffle, LinearLayout.LayoutParams(0,60,1f))
        buttons.addView(fresh, LinearLayout.LayoutParams(0,60,1f))
        root.addView(buttons, LinearLayout.LayoutParams(-1,60))

        setContentView(root)
    }

    private fun startGame() {
        tiles = (0 until n*n).toMutableList()
        do { tiles.shuffle(Random.Default) } while (isSolved())
        selected=-1; moves=0; message.text=""; draw()
    }

    private fun isSolved() = tiles.indices.all { tiles[it] == it }

    private fun draw() {
        grid.removeAllViews()
        grid.columnCount=n; grid.rowCount=n
        val total=n*n
        tiles.forEachIndexed { pos, value ->
            val b=TextView(this).apply {
                text=(value+1).toString()
                textSize=if(n==3) 30f else 20f
                gravity=Gravity.CENTER
                setTextColor(Color.WHITE)
                val g=GradientDrawable().apply {
                    cornerRadius=18f
                    setColor(tileColor(value,total))
                    setStroke(if(pos==selected) 6 else 2, if(pos==selected) Color.WHITE else Color.argb(90,255,255,255))
                }
                background=g
                setOnClickListener { tap(pos) }
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width=0; height=0
                columnSpec=GridLayout.spec(pos%n,1f)
                rowSpec=GridLayout.spec(pos/n,1f)
                setMargins(3,3,3,3)
            })
        }
        movesText.text="Ходы: $moves"
    }

    private fun tileColor(v:Int,total:Int):Int {
        val hue=(v*360f/total)
        val hsv=floatArrayOf(hue,0.55f,0.82f)
        return Color.HSVToColor(hsv)
    }

    private fun tap(i:Int) {
        if(selected==-1) { selected=i; draw(); return }
        if(selected==i) { selected=-1; draw(); return }
        val t=tiles[selected]; tiles[selected]=tiles[i]; tiles[i]=t
        selected=-1; moves++; draw()
        if(isSolved()) message.text="🎉 Картинка собрана!"
    }
}
