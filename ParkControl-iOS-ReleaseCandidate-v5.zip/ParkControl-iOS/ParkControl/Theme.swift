import SwiftUI

enum PC {
    static let bg = Color(red: 0.035, green: 0.039, blue: 0.047)
    static let panel = Color(red: 0.075, green: 0.082, blue: 0.098)
    static let panel2 = Color(red: 0.105, green: 0.113, blue: 0.132)
    static let yellow = Color(red: 1.0, green: 0.80, blue: 0.04)
    static let green = Color(red: 0.24, green: 0.86, blue: 0.48)
    static let red = Color(red: 1.0, green: 0.30, blue: 0.30)
    static let orange = Color(red: 1.0, green: 0.60, blue: 0.20)
    static let secondary = Color.white.opacity(0.55)
    static let hairline = Color.white.opacity(0.07)
}

struct CardModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(PC.panel)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(PC.hairline, lineWidth: 1)
            )
    }
}

extension View {
    func pcCard() -> some View { modifier(CardModifier()) }
}