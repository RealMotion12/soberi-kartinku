
create extension if not exists pgcrypto;

create table if not exists organizations(
 id uuid primary key default gen_random_uuid(),
 name text not null, created_at timestamptz not null default now()
);

create table if not exists users(
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references organizations(id) on delete cascade,
 email text not null unique,
 password_hash text not null,
 role text not null default 'owner',
 created_at timestamptz not null default now()
);

create table if not exists vehicles(
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references organizations(id) on delete cascade,
 brand text not null, model text not null, plate text not null,
 mileage integer not null default 0, status text not null default 'idle',
 next_service text, insurance_until date, created_at timestamptz not null default now(),
 unique(organization_id,plate)
);

create table if not exists employees(
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references organizations(id) on delete cascade,
 name text not null, email text, role text not null default 'observer',
 created_at timestamptz not null default now()
);

create table if not exists inspections(
 id uuid primary key default gen_random_uuid(),
 vehicle_id uuid not null references vehicles(id) on delete cascade,
 employee_id uuid references employees(id) on delete set null,
 mileage integer not null, passed boolean not null default true,
 comment text, created_at timestamptz not null default now()
);

create table if not exists expenses(
 id uuid primary key default gen_random_uuid(),
 vehicle_id uuid not null references vehicles(id) on delete cascade,
 amount numeric(12,2) not null, category text not null, comment text,
 created_at timestamptz not null default now()
);

create table if not exists subscriptions(
 id uuid primary key default gen_random_uuid(),
 user_id uuid references users(id) on delete cascade,
 organization_id uuid not null references organizations(id) on delete cascade,
 product_id text not null,
 original_transaction_id text,
 transaction_id text,
 expires_at timestamptz,
 status text not null default 'active',
 environment text,
 updated_at timestamptz not null default now(),
 unique(product_id, original_transaction_id)
);

create table if not exists apple_notifications(
 id uuid primary key default gen_random_uuid(),
 notification_uuid text unique not null,
 notification_type text,
 subtype text,
 environment text,
 received_at timestamptz not null default now(),
 payload jsonb not null
);

create index if not exists vehicles_org_idx on vehicles(organization_id);
create index if not exists subscriptions_org_idx on subscriptions(organization_id);
