# ParkControl architecture

## Client
SwiftUI / iOS 17 / StoreKit 2.

## Commercial model
One organization (taxi fleet) owns the workspace. Owner/admins manage employees and fleet.
The monthly Pro subscription is attached to the user's UUID through StoreKit `appAccountToken`.

## Server
Node.js 20 + Express + PostgreSQL. Multi-tenant rows are scoped by `organization_id`.
Authentication uses bcrypt password hashes + signed JWTs.

## Apple billing
The iOS client handles purchase/restore/entitlements. The server receives App Store Server
Notifications V2 and verifies signed payloads using Apple's official Node library. The verified
transaction's `appAccountToken` is mapped to the ParkControl user.

## Core data
Organizations, users, vehicles, employees, inspections, expenses, subscriptions,
and Apple notification audit records.

## Security requirements for deployment
HTTPS, private PostgreSQL, secrets in environment/secret manager, daily backups,
object storage for uploaded documents/photos, audit logs, rate limiting, monitoring.
