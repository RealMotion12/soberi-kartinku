import SwiftUI
import StoreKit


@MainActor
final class SubscriptionManager: ObservableObject {
    static let shared = SubscriptionManager()

    @Published private(set) var products: [Product] = []
    @Published private(set) var isSubscribed = false
    @Published private(set) var isLoading = false
    @Published var message: String?

    let monthlyProductID = "com.realmotion12.parkcontrol.pro.monthly"
    private var updatesTask: Task<Void, Never>?

    init() {
        updatesTask = Task { [weak self] in await self?.observeTransactions() }
        Task { await load() }
    }

    deinit { updatesTask?.cancel() }

    func load() async {
        isLoading = true
        defer { isLoading = false }
        do {
            products = try await Product.products(for: [monthlyProductID])
            await refreshEntitlement()
        } catch {
            message = "Не удалось загрузить подписку."
        }
    }

    func purchase() async {
        guard let product = products.first else { await load(); return }
        do {
            let accountToken = SessionStore.shared.userUUID
            let result = try await product.purchase(options: [.appAccountToken(accountToken)])
            switch result {
            case .success(let verification):
                let transaction = try checkVerified(verification)
                await transaction.finish()
                await refreshEntitlement()
            case .userCancelled:
                break
            case .pending:
                message = "Покупка ожидает подтверждения."
            @unknown default:
                break
            }
        } catch {
            message = "Покупку не удалось завершить."
        }
    }

    func restore() async {
        do {
            try await AppStore.sync()
            await refreshEntitlement()
        } catch {
            message = "Не удалось восстановить покупки."
        }
    }

    func manageSubscription() async {
        do {
            try await AppStore.showManageSubscriptions(in: nil)
        } catch {
            message = "Откройте управление подписками в настройках Apple ID."
        }
    }

    private func refreshEntitlement() async {
        var active = false
        for await result in Transaction.currentEntitlements {
            if case .verified(let transaction) = result,
               transaction.productID == monthlyProductID,
               transaction.revocationDate == nil {
                active = true
            }
        }
        isSubscribed = active
    }

    private func observeTransactions() async {
        for await result in Transaction.updates {
            if case .verified(let transaction) = result {
                if transaction.productID == monthlyProductID {
                    await transaction.finish()
                }
                await refreshEntitlement()
            }
        }
    }

    private func checkVerified<T>(_ result: VerificationResult<T>) throws -> T {
        switch result {
        case .verified(let safe): return safe
        case .unverified: throw StoreError.failedVerification
        }
    }

    enum StoreError: Error { case failedVerification }
}

struct SubscriptionView: View {
    @StateObject private var store = SubscriptionManager.shared

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 18) {
                VStack(spacing: 12) {
                    ZStack {
                        Circle().fill(PC.yellow.opacity(0.10)).frame(width: 86, height: 86)
                        Image(systemName: "crown.fill")
                            .font(.system(size: 30, weight: .bold))
                            .foregroundStyle(PC.yellow)
                    }
                    Text("ПаркКонтроль Pro")
                        .font(.system(size: 28, weight: .bold, design: .rounded))
                    Text("Всё управление таксопарком в одном приложении")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(PC.secondary)
                        .multilineTextAlignment(.center)
                }
                .padding(.top, 24)

                VStack(alignment: .leading, spacing: 12) {
                    SubscriptionFeature(icon: "car.fill", text: "Управление всем автопарком")
                    SubscriptionFeature(icon: "checkmark.shield.fill", text: "Осмотры, ТО и документы")
                    SubscriptionFeature(icon: "chart.bar.fill", text: "Расходы и история")
                    SubscriptionFeature(icon: "person.2.fill", text: "Сотрудники и роли")
                    SubscriptionFeature(icon: "arrow.triangle.2.circlepath", text: "Облачная синхронизация")
                }
                .padding(18)
                .pcCard()

                if let product = store.products.first {
                    VStack(spacing: 10) {
                        Text(product.displayPrice + " / месяц")
                            .font(.system(size: 28, weight: .bold, design: .rounded))
                        Text("Автопродление. Отменить можно в настройках Apple ID.")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundStyle(PC.secondary)
                            .multilineTextAlignment(.center)

                        Button {
                            Task { await store.purchase() }
                        } label: {
                            Text(store.isSubscribed ? "Подписка активна" : "Подключить Pro")
                                .font(.system(size: 15, weight: .bold))
                                .frame(maxWidth: .infinity).frame(height: 54)
                                .background(store.isSubscribed ? PC.panel2 : PC.yellow)
                                .foregroundStyle(store.isSubscribed ? .white : .black)
                                .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
                        }
                        .disabled(store.isSubscribed)
                    }
                    .padding(18)
                    .pcCard()
                } else {
                    VStack(spacing: 10) {
                        ProgressView().tint(PC.yellow)
                        Text("Загрузка тарифа…")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(PC.secondary)
                    }
                    .frame(maxWidth: .infinity).padding(28).pcCard()
                }

                Button("Восстановить покупку") {
                    Task { await store.restore() }
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(PC.yellow)

                if store.isSubscribed {
                    Button("Управление подпиской") {
                        Task { await store.manageSubscription() }
                    }
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(PC.secondary)
                }

                Text("Оплата, продление и отмена подписки оформляются через Apple.")
                    .font(.system(size: 9, weight: .medium))
                    .foregroundStyle(PC.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 18)
            }
            .padding(.horizontal, 18)
        }
        .background(PC.bg)
        .navigationTitle("Подписка")
        .navigationBarTitleDisplayMode(.inline)
        .alert("ПаркКонтроль", isPresented: Binding(
            get: { store.message != nil },
            set: { if !$0 { store.message = nil } }
        )) {
            Button("OK") { store.message = nil }
        } message: {
            Text(store.message ?? "")
        }
    }
}

struct SubscriptionFeature: View {
    let icon: String
    let text: String
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(PC.yellow).frame(width: 28)
            Text(text).font(.system(size: 13, weight: .semibold))
            Spacer()
            Image(systemName: "checkmark")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(PC.green)
        }
    }
}


struct APIClient {
    let baseURL: URL

    func post<T: Decodable>(_ path: String, body: [String: Any]) async throws -> T {
        var request = URLRequest(url: baseURL.appending(path: path))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw APIError.server
        }
        return try JSONDecoder().decode(T.self, from: data)
    }

    func delete(path: String, token: String) async throws {
        var request = URLRequest(url: baseURL.appending(path: path))
        request.httpMethod = "DELETE"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw APIError.server
        }
    }

    enum APIError: Error { case server }
}

struct AuthResponse: Decodable {
    struct User: Decodable { let id: String; let email: String; let organization_id: String; let role: String }
    struct Organization: Decodable { let id: String; let name: String }
    let token: String
    let user: User
    let organization: Organization
}

@MainActor
final class SessionStore: ObservableObject {
    static let shared = SessionStore()

    @Published var token: String = UserDefaults.standard.string(forKey: "pc.token") ?? ""
    @Published var email: String = UserDefaults.standard.string(forKey: "pc.email") ?? ""
    @Published var organizationName: String = UserDefaults.standard.string(forKey: "pc.orgName") ?? "Мой таксопарк"
    @Published var userID: String = UserDefaults.standard.string(forKey: "pc.userID") ?? UUID().uuidString
    @Published var message: String?

    // Set this to the deployed HTTPS API before App Store submission.
    // Leave empty for local UI/demo mode.
    let apiBaseURL = UserDefaults.standard.string(forKey: "pc.apiBaseURL") ?? ""

    var isLoggedIn: Bool { !token.isEmpty }
    var userUUID: UUID { UUID(uuidString: userID) ?? UUID() }

    private var api: APIClient? {
        guard !apiBaseURL.isEmpty, let url = URL(string: apiBaseURL) else { return nil }
        return APIClient(baseURL: url)
    }

    func login(email: String, password: String) async {
        do {
            if let api {
                let r: AuthResponse = try await api.post("/api/v1/auth/login", body: ["email": email, "password": password])
                apply(r)
                return
            }
            demoLogin(email: email)
        } catch { message = "Не удалось войти. Проверьте email и пароль." }
    }

    func register(email: String, password: String, organization: String) async {
        do {
            if let api {
                let r: AuthResponse = try await api.post("/api/v1/auth/register", body: [
                    "email": email, "password": password, "organizationName": organization
                ])
                apply(r)
                return
            }
            self.email = email
            self.organizationName = organization.isEmpty ? "Мой таксопарк" : organization
            self.userID = UUID().uuidString
            self.token = "demo-\(UUID().uuidString)"
            persist()
        } catch { message = "Не удалось создать аккаунт." }
    }

    private func demoLogin(email: String) {
        self.email = email
        if userID.isEmpty { userID = UUID().uuidString }
        token = "demo-\(UUID().uuidString)"
        persist()
    }

    private func apply(_ r: AuthResponse) {
        token = r.token
        email = r.user.email
        userID = r.user.id
        organizationName = r.organization.name
        persist()
    }

    private func persist() {
        UserDefaults.standard.set(token, forKey: "pc.token")
        UserDefaults.standard.set(email, forKey: "pc.email")
        UserDefaults.standard.set(userID, forKey: "pc.userID")
        UserDefaults.standard.set(organizationName, forKey: "pc.orgName")
    }

    func logout() {
        token = ""
        email = ""
        UserDefaults.standard.removeObject(forKey: "pc.token")
        UserDefaults.standard.removeObject(forKey: "pc.email")
    }

    func deleteAccount() async {
        do {
            if let api { try await api.delete(path: "/api/v1/account", token: token) }
            logout()
        } catch { message = "Не удалось удалить аккаунт. Попробуйте ещё раз." }
    }
}


struct VehicleDTO: Decodable {
    let id: String
    let brand: String
    let model: String
    let plate: String
    let mileage: Int
    let status: String
    let next_service: String?
    let insurance_until: String?

    func modelValue() -> Vehicle {
        let idValue = UUID(uuidString: id) ?? UUID()
        let statusValue: Vehicle.Status = {
            switch status { case "line": return .line; case "repair": return .repair; default: return .idle }
        }()
        var v = Vehicle(brand: brand, model: model, plate: plate, mileage: mileage,
                        status: statusValue, nextService: next_service ?? "Не задано",
                        insurance: insurance_until ?? "Не задано", serverID: id)
        _ = idValue
        return v
    }
}

extension SessionStore {
    func fetchVehicles() async -> [Vehicle]? {
        guard let api else { return nil }
        do {
            var request = URLRequest(url: api.baseURL.appending(path: "/api/v1/vehicles"))
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { return nil }
            return try JSONDecoder().decode([VehicleDTO].self, from: data).map { $0.modelValue() }
        } catch { return nil }
    }

    func createVehicle(_ vehicle: Vehicle) async -> Vehicle? {
        guard let api else { return nil }
        do {
            let body: [String: Any] = [
                "brand": vehicle.brand, "model": vehicle.model, "plate": vehicle.plate,
                "mileage": vehicle.mileage, "status": "idle",
                "nextService": NSNull(), "insuranceUntil": NSNull()
            ]
            let result: VehicleDTO = try await api.post("/api/v1/vehicles", body: body)
            return result.modelValue()
        } catch { return nil }
    }

    func submitInspection(vehicle: Vehicle, mileage: Int, passed: Bool, comment: String) async -> Bool {
        guard let api else { return true }
        do {
            let _: EmptyResponse = try await api.post("/api/v1/inspections", body: [
                "vehicleId": vehicle.serverID ?? "", "mileage": mileage, "passed": passed, "comment": comment
            ])
            return true
        } catch { return false }
    }
}

struct EmptyResponse: Decodable {}

struct AuthView: View {
    @StateObject private var session = SessionStore.shared
    @State private var isRegister = true
    @State private var email = ""
    @State private var password = ""
    @State private var organization = ""

    var body: some View {
        ZStack {
            PC.bg.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    Spacer(minLength: 55)

                    ZStack {
                        Circle().fill(PC.yellow.opacity(0.11)).frame(width: 92, height: 92)
                        Image(systemName: "car.fill")
                            .font(.system(size: 34, weight: .bold))
                            .foregroundStyle(PC.yellow)
                    }

                    VStack(spacing: 5) {
                        Text("ПаркКонтроль")
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                        Text(isRegister ? "Создайте аккаунт таксопарка" : "Вход в таксопарк")
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(PC.secondary)
                    }

                    VStack(spacing: 11) {
                        AuthField(icon: "building.2.fill", placeholder: "Название таксопарка", text: $organization)
                            .opacity(isRegister ? 1 : 0)
                            .frame(height: isRegister ? 52 : 0)

                        AuthField(icon: "envelope.fill", placeholder: "Email", text: $email)
                        AuthField(icon: "lock.fill", placeholder: "Пароль", text: $password, secure: true)
                    }
                    .padding(18)
                    .pcCard()

                    Button {
                        Task {
                            if isRegister {
                                await session.register(email: email, password: password, organization: organization)
                            } else {
                                await session.login(email: email, password: password)
                            }
                        }
                    } label: {
                        Text(isRegister ? "Создать аккаунт" : "Войти")
                            .font(.system(size: 15, weight: .bold))
                            .foregroundStyle(.black)
                            .frame(maxWidth: .infinity)
                            .frame(height: 54)
                            .background(PC.yellow)
                            .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
                    }

                    Button(isRegister ? "У меня уже есть аккаунт" : "Создать новый аккаунт") {
                        withAnimation(.easeInOut(duration: 0.2)) { isRegister.toggle() }
                    }
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(PC.yellow)

                    Text("Продолжая, вы принимаете Условия использования и Политику конфиденциальности.")
                        .font(.system(size: 9, weight: .medium))
                        .foregroundStyle(PC.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 22)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct AuthField: View {
    let icon: String
    let placeholder: String
    @Binding var text: String
    var secure = false

    var body: some View {
        HStack(spacing: 11) {
            Image(systemName: icon).foregroundStyle(PC.secondary).frame(width: 20)
            if secure {
                SecureField(placeholder, text: $text)
            } else {
                TextField(placeholder, text: $text)
                    .textInputAutocapitalization(.never)
                    .keyboardType(placeholder == "Email" ? .emailAddress : .default)
            }
        }
        .font(.system(size: 14, weight: .medium))
        .padding(.horizontal, 14)
        .frame(height: 50)
        .background(PC.panel2)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var vehicles = demoVehicles
    @State private var showingAdd = false
    @State private var showingNotifications = false

    @StateObject private var session = SessionStore.shared

    var body: some View {
        if session.isLoggedIn {
            ZStack {
                PC.bg.ignoresSafeArea()

                TabView(selection: $selectedTab) {
                DashboardView(
                    vehicles: vehicles,
                    onAdd: { showingAdd = true },
                    onNotifications: { showingNotifications = true }
                )
                .tag(0)
                .tabItem { Label("Обзор", systemImage: "square.grid.2x2.fill") }

                VehiclesView(vehicles: vehicles)
                    .tag(1)
                    .tabItem { Label("Парк", systemImage: "car.fill") }

                InspectionView(vehicles: vehicles)
                    .tag(2)
                    .tabItem { Label("Осмотры", systemImage: "checkmark.shield.fill") }

                MoreView()
                    .tag(3)
                    .tabItem { Label("Ещё", systemImage: "ellipsis") }
            }
            .tint(PC.yellow)
                .sheet(isPresented: $showingAdd) { AddVehicleSheet { vehicle in
                    Task {
                        if let saved = await session.createVehicle(vehicle) { vehicles.insert(saved, at: 0) }
                        else { vehicles.insert(vehicle, at: 0) }
                    }
                } }
                .sheet(isPresented: $showingNotifications) { NotificationsSheet() }
                .task {
                    if let synced = await session.fetchVehicles() { vehicles = synced }
                }
            }
        } else {
            AuthView()
        }
    }
}

struct DashboardView: View {
    let vehicles: [Vehicle]
    let onAdd: () -> Void
    let onNotifications: () -> Void

    private var line: Int { vehicles.filter { $0.status == .line }.count }
    private var repair: Int { vehicles.filter { $0.status == .repair }.count }
    private var idle: Int { vehicles.filter { $0.status == .idle }.count }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    topBar
                    overviewCard
                    liveStatus
                    attentionCard
                    fleetSection
                }
                .padding(.horizontal, 18)
                .padding(.top, 8)
                .padding(.bottom, 30)
            }
            .background(PC.bg)
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private var topBar: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 4) {
                Text("ПаркКонтроль")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .tracking(-0.6)
                Text("Доброе утро")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(PC.secondary)
            }

            Spacer()

            Button(action: onNotifications) {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: "bell.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 46, height: 46)
                        .background(PC.panel)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(PC.hairline))
                    Circle()
                        .fill(PC.yellow)
                        .frame(width: 8, height: 8)
                        .overlay(Circle().stroke(PC.bg, lineWidth: 2))
                        .offset(x: -4, y: 3)
                }
            }
            .buttonStyle(.plain)
        }
    }

    private var overviewCard: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("АВТОПАРК")
                        .font(.system(size: 11, weight: .heavy))
                        .foregroundStyle(PC.secondary)
                        .tracking(1.4)
                    Text("\(vehicles.count)")
                        .font(.system(size: 54, weight: .heavy, design: .rounded))
                        .tracking(-2)
                    Text("автомобиля")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(PC.secondary)
                }
                Spacer()
                ZStack {
                    Circle()
                        .stroke(Color.white.opacity(0.07), lineWidth: 11)
                    Circle()
                        .trim(from: 0, to: 0.86)
                        .stroke(
                            PC.yellow,
                            style: StrokeStyle(lineWidth: 11, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                    VStack(spacing: 1) {
                        Text("86%")
                            .font(.system(size: 19, weight: .bold, design: .rounded))
                        Text("активны")
                            .font(.system(size: 9, weight: .medium))
                            .foregroundStyle(PC.secondary)
                    }
                }
                .frame(width: 94, height: 94)
            }

            HStack(spacing: 9) {
                MiniMetric(title: "На линии", value: line, color: PC.green)
                MiniMetric(title: "Ремонт", value: repair, color: PC.orange)
                MiniMetric(title: "Простой", value: idle, color: PC.secondary)
            }
        }
        .padding(22)
        .background(
            LinearGradient(
                colors: [
                    PC.panel2,
                    PC.panel,
                    Color(red: 0.055, green: 0.06, blue: 0.072)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [PC.yellow.opacity(0.22), Color.white.opacity(0.04)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1
                )
        )
        .shadow(color: .black.opacity(0.24), radius: 24, y: 12)
    }

    private var liveStatus: some View {
        VStack(alignment: .leading, spacing: 13) {
            SectionHeader(title: "Сейчас", trailing: "LIVE")
            HStack(spacing: 0) {
                LiveCell(value: line, label: "На линии", color: PC.green)
                Divider().overlay(PC.hairline)
                LiveCell(value: repair, label: "В ремонте", color: PC.orange)
                Divider().overlay(PC.hairline)
                LiveCell(value: idle, label: "Простой", color: PC.secondary)
            }
            .frame(height: 78)
            .pcCard()
        }
    }

    private var attentionCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "Требует внимания", trailing: "3")

            CompactAlert(icon: "speedometer", title: "ТО", detail: "3 автомобиля", color: PC.yellow)
            CompactAlert(icon: "shield.lefthalf.filled", title: "ОСАГО", detail: "1 заканчивается", color: PC.red)
            CompactAlert(icon: "wrench.and.screwdriver.fill", title: "Ремонт", detail: "2 автомобиля", color: PC.orange)
        }
        .padding(18)
        .pcCard()
    }

    private var fleetSection: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                SectionHeader(title: "Парк", trailing: nil)
                Spacer()
                Button(action: onAdd) {
                    Image(systemName: "plus")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(PC.bg)
                        .frame(width: 36, height: 36)
                        .background(PC.yellow)
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }

            ForEach(vehicles) { vehicle in
                VehicleRow(vehicle: vehicle)
            }
        }
    }
}

struct SectionHeader: View {
    let title: String
    let trailing: String?

    var body: some View {
        HStack(alignment: .center) {
            Text(title)
                .font(.system(size: 19, weight: .bold, design: .rounded))
                .tracking(-0.3)
            if let trailing {
                Spacer()
                Text(trailing)
                    .font(.system(size: 11, weight: .heavy))
                    .foregroundStyle(PC.yellow)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 5)
                    .background(PC.yellow.opacity(0.10))
                    .clipShape(Capsule())
            }
        }
    }
}

struct MiniMetric: View {
    let title: String
    let value: Int
    let color: Color

    var body: some View {
        HStack(spacing: 7) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text("\(value)")
                .font(.system(size: 15, weight: .bold, design: .rounded))
            Text(title)
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(PC.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct LiveCell: View {
    let value: Int
    let label: String
    let color: Color

    var body: some View {
        VStack(spacing: 5) {
            HStack(spacing: 6) {
                Circle().fill(color).frame(width: 6, height: 6)
                Text("\(value)")
                    .font(.system(size: 21, weight: .bold, design: .rounded))
            }
            Text(label)
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(PC.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

struct CompactAlert: View {
    let icon: String
    let title: String
    let detail: String
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(color)
                .frame(width: 36, height: 36)
                .background(color.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))

            Text(title)
                .font(.system(size: 14, weight: .semibold))
            Spacer()
            Text(detail)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(PC.secondary)
            Image(systemName: "chevron.right")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(PC.secondary)
        }
    }
}

struct VehicleRow: View {
    let vehicle: Vehicle

    var statusColor: Color {
        switch vehicle.status {
        case .line: PC.green
        case .repair: PC.orange
        case .idle: PC.secondary
        }
    }

    var body: some View {
        HStack(spacing: 13) {
            ZStack {
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .fill(PC.yellow.opacity(0.09))
                Image(systemName: "car.fill")
                    .font(.system(size: 19, weight: .bold))
                    .foregroundStyle(PC.yellow)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 4) {
                Text("\(vehicle.brand) \(vehicle.model)")
                    .font(.system(size: 15, weight: .bold))
                HStack(spacing: 6) {
                    Text(vehicle.plate)
                        .font(.system(size: 11, weight: .semibold))
                    Text("•")
                        .foregroundStyle(PC.secondary)
                    Text("\(vehicle.mileage.formatted()) км")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(PC.secondary)
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 6) {
                HStack(spacing: 5) {
                    Circle().fill(statusColor).frame(width: 6, height: 6)
                    Text(vehicle.status.rawValue)
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(statusColor)
                }
                Image(systemName: "chevron.right")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(PC.secondary)
            }
        }
        .padding(14)
        .pcCard()
    }
}

struct VehiclesView: View {
    let vehicles: [Vehicle]
    @State private var query = ""

    var filtered: [Vehicle] {
        if query.isEmpty { return vehicles }
        return vehicles.filter {
            "\($0.brand) \($0.model) \($0.plate)"
                .localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Парк")
                                .font(.system(size: 31, weight: .bold, design: .rounded))
                            Text("\(vehicles.count) автомобилей")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(PC.secondary)
                        }
                        Spacer()
                    }
                    .padding(.top, 8)

                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass")
                        TextField("Марка, модель или номер", text: $query)
                            .textInputAutocapitalization(.never)
                    }
                    .foregroundStyle(PC.secondary)
                    .padding(.horizontal, 14)
                    .frame(height: 50)
                    .background(PC.panel)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

                    LazyVStack(spacing: 10) {
                        ForEach(filtered) { vehicle in
                            NavigationLink {
                                VehicleDetailView(vehicle: vehicle)
                            } label: {
                                VehicleRow(vehicle: vehicle)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 28)
            }
            .background(PC.bg)
            .toolbar(.hidden, for: .navigationBar)
        }
    }
}

struct VehicleDetailView: View {
    let vehicle: Vehicle

    private var statusColor: Color {
        switch vehicle.status {
        case .line: PC.green
        case .repair: PC.orange
        case .idle: PC.secondary
        }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                hero
                quickActions
                vehicleFacts
                serviceCard
                insuranceCard
                expensesCard
                historyCard
            }
            .padding(.horizontal, 18)
            .padding(.bottom, 32)
        }
        .background(PC.bg)
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var hero: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [PC.yellow.opacity(0.20), PC.yellow.opacity(0.02)],
                            center: .center,
                            startRadius: 2,
                            endRadius: 82
                        )
                    )
                    .frame(width: 132, height: 132)

                Image(systemName: "car.fill")
                    .font(.system(size: 48, weight: .bold))
                    .foregroundStyle(PC.yellow)
            }

            VStack(spacing: 5) {
                Text("\(vehicle.brand) \(vehicle.model)")
                    .font(.system(size: 27, weight: .bold, design: .rounded))
                    .tracking(-0.5)

                Text(vehicle.plate)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundStyle(PC.secondary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color.white.opacity(0.06))
                    .clipShape(Capsule())

                HStack(spacing: 6) {
                    Circle()
                        .fill(statusColor)
                        .frame(width: 7, height: 7)
                    Text(vehicle.status.rawValue)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(statusColor)
                }
                .padding(.top, 3)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 8)
        .padding(.bottom, 4)
    }

    private var quickActions: some View {
        HStack(spacing: 10) {
            DetailAction(icon: "gauge.with.dots.needle.33percent", title: "Пробег")
            DetailAction(icon: "wrench.and.screwdriver.fill", title: "Ремонт")
            DetailAction(icon: "doc.text.fill", title: "Документы")
            DetailAction(icon: "clock.arrow.circlepath", title: "История")
        }
    }

    private var vehicleFacts: some View {
        HStack(spacing: 0) {
            DetailMetric(title: "Пробег", value: "\(vehicle.mileage.formatted())", suffix: "км")
            Divider().frame(height: 44).overlay(PC.hairline)
            DetailMetric(title: "Следующее ТО", value: vehicle.nextService, suffix: "")
            Divider().frame(height: 44).overlay(PC.hairline)
            DetailMetric(title: "ОСАГО до", value: vehicle.insurance, suffix: "")
        }
        .padding(.vertical, 17)
        .pcCard()
    }

    private var serviceCard: some View {
        DetailInfoCard(
            icon: "wrench.and.screwdriver.fill",
            title: "Техническое обслуживание",
            subtitle: "Следующее ТО",
            value: vehicle.nextService,
            color: PC.yellow
        )
    }

    private var insuranceCard: some View {
        DetailInfoCard(
            icon: "shield.checkered",
            title: "ОСАГО",
            subtitle: "Действует до",
            value: vehicle.insurance,
            color: PC.green
        )
    }

    private var expensesCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Label("Расходы", systemImage: "rublesign.circle.fill")
                    .font(.system(size: 16, weight: .bold))
                Spacer()
                Text("За месяц")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(PC.secondary)
            }

            HStack(alignment: .bottom) {
                Text("42 850 ₽")
                    .font(.system(size: 27, weight: .bold, design: .rounded))
                Spacer()
                Text("+8.4%")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(PC.orange)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 6)
                    .background(PC.orange.opacity(0.10))
                    .clipShape(Capsule())
            }

            HStack(spacing: 5) {
                ExpenseBar(label: "ТО", value: 0.72)
                ExpenseBar(label: "Ремонт", value: 0.46)
                ExpenseBar(label: "Прочее", value: 0.25)
            }
        }
        .padding(18)
        .pcCard()
    }

    private var historyCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Text("История")
                    .font(.system(size: 16, weight: .bold))
                Spacer()
                Text("Все")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(PC.yellow)
            }

            HistoryLine(icon: "wrench.fill", title: "Плановое ТО", date: "18.09.2026", color: PC.yellow)
            HistoryLine(icon: "fuelpump.fill", title: "Заправка", date: "17.09.2026", color: PC.green)
            HistoryLine(icon: "car.fill", title: "Осмотр", date: "15.09.2026", color: PC.secondary)
        }
        .padding(18)
        .pcCard()
    }
}

struct DetailAction: View {
    let icon: String
    let title: String

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(PC.yellow)
                .frame(width: 42, height: 42)
                .background(PC.yellow.opacity(0.09))
                .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
            Text(title)
                .font(.system(size: 9, weight: .semibold))
                .foregroundStyle(PC.secondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity)
    }
}

struct DetailMetric: View {
    let title: String
    let value: String
    let suffix: String

    var body: some View {
        VStack(spacing: 5) {
            Text(title)
                .font(.system(size: 9, weight: .medium))
                .foregroundStyle(PC.secondary)
            HStack(alignment: .lastTextBaseline, spacing: 3) {
                Text(value)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                if !suffix.isEmpty {
                    Text(suffix)
                        .font(.system(size: 8, weight: .medium))
                        .foregroundStyle(PC.secondary)
                }
            }
            .lineLimit(1)
            .minimumScaleFactor(0.65)
        }
        .frame(maxWidth: .infinity)
    }
}

struct DetailInfoCard: View {
    let icon: String
    let title: String
    let subtitle: String
    let value: String
    let color: Color

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(color)
                .frame(width: 42, height: 42)
                .background(color.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 14, weight: .bold))
                Text(subtitle)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(PC.secondary)
            }

            Spacer()

            Text(value)
                .font(.system(size: 13, weight: .bold, design: .rounded))
        }
        .padding(16)
        .pcCard()
    }
}

struct ExpenseBar: View {
    let label: String
    let value: CGFloat

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            GeometryReader { proxy in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.05))
                    Capsule().fill(PC.yellow).frame(width: proxy.size.width * value)
                }
            }
            .frame(height: 5)

            Text(label)
                .font(.system(size: 9, weight: .medium))
                .foregroundStyle(PC.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

struct HistoryLine: View {
    let icon: String
    let title: String
    let date: String
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(color)
                .frame(width: 34, height: 34)
                .background(color.opacity(0.09))
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

            Text(title)
                .font(.system(size: 13, weight: .semibold))
            Spacer()
            Text(date)
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(PC.secondary)
        }
    }
}

struct InspectionView: View {
    let vehicles: [Vehicle]
    @State private var selectedVehicle: Vehicle?

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    HStack(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Осмотры")
                                .font(.system(size: 31, weight: .bold, design: .rounded))
                            Text("Контроль состояния автопарка")
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(PC.secondary)
                        }
                        Spacer()
                    }
                    .padding(.top, 8)

                    HStack(spacing: 12) {
                        Image(systemName: "checkmark.shield.fill")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundStyle(PC.yellow)
                            .frame(width: 46, height: 46)
                            .background(PC.yellow.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Сегодня")
                                .font(.system(size: 15, weight: .bold))
                            Text("\(vehicles.count) автомобилей в парке")
                                .font(.system(size: 12))
                                .foregroundStyle(PC.secondary)
                        }
                        Spacer()
                    }
                    .padding(16)
                    .pcCard()

                    SectionHeader(title: "Очередь", trailing: "\(vehicles.count)")
                    ForEach(vehicles) { vehicle in
                        Button { selectedVehicle = vehicle } label: {
                            InspectionTask(vehicle: vehicle)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 28)
            }
            .background(PC.bg)
            .toolbar(.hidden, for: .navigationBar)
            .sheet(item: $selectedVehicle) { vehicle in
                InspectionWizardView(vehicle: vehicle)
            }
        }
    }
}

struct InspectionTask: View {
    let vehicle: Vehicle

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: "car.fill")
                .foregroundStyle(PC.yellow)
                .frame(width: 42, height: 42)
                .background(PC.yellow.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

            VStack(alignment: .leading, spacing: 4) {
                Text("\(vehicle.brand) \(vehicle.model)").font(.system(size: 14, weight: .bold))
                Text("\(vehicle.plate) • \(vehicle.mileage.formatted()) км")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(PC.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(PC.secondary)
        }
        .padding(15)
        .pcCard()
    }
}

struct InspectionWizardView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var session = SessionStore.shared
    let vehicle: Vehicle
    @State private var mileage = ""
    @State private var damage = false
    @State private var lights = true
    @State private var tires = true
    @State private var seatbelts = true
    @State private var firstAid = true
    @State private var fireExtinguisher = true
    @State private var comment = ""
    @State private var saving = false
    @State private var done = false

    private var passed: Bool { lights && tires && seatbelts && firstAid && fireExtinguisher && !damage }

    var body: some View {
        NavigationStack {
            Form {
                Section("Автомобиль") {
                    LabeledContent("Авто", value: "\(vehicle.brand) \(vehicle.model)")
                    LabeledContent("Текущий пробег", value: "\(vehicle.mileage.formatted()) км")
                    TextField("Новый пробег", text: $mileage)
                        .keyboardType(.numberPad)
                }

                Section("Проверка") {
                    Toggle("Фары и свет", isOn: $lights)
                    Toggle("Шины", isOn: $tires)
                    Toggle("Ремни безопасности", isOn: $seatbelts)
                    Toggle("Аптечка", isOn: $firstAid)
                    Toggle("Огнетушитель", isOn: $fireExtinguisher)
                    Toggle("Есть повреждения", isOn: $damage)
                }

                Section("Комментарий") {
                    TextField("Комментарий механика", text: $comment, axis: .vertical)
                }

                Section {
                    Button {
                        Task {
                            saving = true
                            let value = max(vehicle.mileage, Int(mileage) ?? vehicle.mileage)
                            let ok = await session.submitInspection(vehicle: vehicle, mileage: value, passed: passed, comment: comment)
                            saving = false
                            if ok { done = true }
                        }
                    } label: {
                        HStack {
                            Spacer()
                            if saving { ProgressView().tint(PC.yellow) }
                            else { Text(passed ? "Завершить осмотр" : "Завершить с замечаниями").fontWeight(.bold) }
                            Spacer()
                        }
                    }
                    .foregroundStyle(passed ? PC.yellow : PC.orange)
                }
            }
            .scrollContentBackground(.hidden)
            .background(PC.bg)
            .navigationTitle("Осмотр")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } }
            }
            .alert("Осмотр сохранён", isPresented: $done) {
                Button("Готово") { dismiss() }
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct MoreView: View {
    @StateObject private var session = SessionStore.shared
    @State private var showingDelete = false

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 12) {
                    AccountHeader()

                    NavigationLink {
                        SubscriptionView()
                    } label: {
                        ProBanner()
                    }
                    .buttonStyle(.plain)

                    MoreRow(icon: "person.2.fill", title: "Сотрудники", subtitle: "Роли и доступ")
                    MoreRow(icon: "bell.badge.fill", title: "Уведомления", subtitle: "ТО, ОСАГО, ремонт")
                    MoreRow(icon: "chart.bar.xaxis", title: "Отчёты", subtitle: "Парк и расходы")
                    MoreRow(icon: "tablecells", title: "Excel", subtitle: "Импорт и экспорт")
                    MoreRow(icon: "arrow.triangle.2.circlepath", title: "1С", subtitle: "Синхронизация")
                    MoreRow(icon: "building.2.fill", title: "Таксопарк", subtitle: "Название и реквизиты")

                    VStack(spacing: 0) {
                        Button {
                            session.logout()
                        } label: {
                            MoreRowContent(icon: "rectangle.portrait.and.arrow.right",
                                           title: "Выйти",
                                           subtitle: "Завершить текущую сессию",
                                           tint: PC.secondary)
                        }

                        Divider().overlay(PC.hairline)

                        Button(role: .destructive) {
                            showingDelete = true
                        } label: {
                            MoreRowContent(icon: "trash.fill",
                                           title: "Удалить аккаунт",
                                           subtitle: "Удаление данных таксопарка",
                                           tint: PC.red)
                        }
                    }
                    .padding(.horizontal, 15)
                    .background(PC.panel)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(PC.hairline, lineWidth: 1))

                    Text("ПаркКонтроль • Pro")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(PC.secondary)
                        .padding(.vertical, 12)
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 30)
            }
            .background(PC.bg)
            .navigationTitle("Ещё")
            .navigationBarTitleDisplayMode(.large)
            .confirmationDialog("Удалить аккаунт?", isPresented: $showingDelete, titleVisibility: .visible) {
                Button("Удалить аккаунт", role: .destructive) {
                    Task { await session.deleteAccount() }
                }
                Button("Отмена", role: .cancel) {}
            } message: {
                Text("Будут удалены аккаунт и связанные данные таксопарка. Активную подписку нужно отдельно отменить через Apple.")
            }
            .alert("ПаркКонтроль", isPresented: Binding(
                get: { session.message != nil },
                set: { if !$0 { session.message = nil } }
            )) {
                Button("OK") { session.message = nil }
            } message: {
                Text(session.message ?? "")
            }
        }
    }
}

struct AccountHeader: View {
    @StateObject private var session = SessionStore.shared

    var body: some View {
        HStack(spacing: 13) {
            ZStack {
                Circle().fill(PC.yellow.opacity(0.12))
                Image(systemName: "building.2.fill")
                    .foregroundStyle(PC.yellow)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 4) {
                Text(session.organizationName)
                    .font(.system(size: 16, weight: .bold))
                Text(session.email.isEmpty ? "Демо-режим" : session.email)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(PC.secondary)
            }
            Spacer()
        }
        .padding(16)
        .pcCard()
    }
}

struct ProBanner: View {
    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: "crown.fill")
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(.black)
                .frame(width: 42, height: 42)
                .background(PC.yellow)
                .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))

            VStack(alignment: .leading, spacing: 4) {
                Text("ПаркКонтроль Pro")
                    .font(.system(size: 15, weight: .bold))
                Text("5 000 ₽ / месяц")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(PC.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(PC.secondary)
        }
        .padding(15)
        .background(PC.yellow.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(PC.yellow.opacity(0.20), lineWidth: 1))
    }
}

struct MoreRow: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        MoreRowContent(icon: icon, title: title, subtitle: subtitle, tint: PC.yellow)
            .padding(15)
            .pcCard()
    }
}

struct MoreRowContent: View {
    let icon: String
    let title: String
    let subtitle: String
    let tint: Color

    var body: some View {
        HStack(spacing: 13) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(tint)
                .frame(width: 42, height: 42)
                .background(tint.opacity(0.09))
                .clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))

            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 14, weight: .bold))
                Text(subtitle)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(PC.secondary)
            }

            Spacer()
            Image(systemName: "chevron.right")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(PC.secondary)
        }
    }
}

struct AddVehicleSheet: View {
    @Environment(\.dismiss) private var dismiss
    let onSave: (Vehicle) -> Void

    @State private var brand = ""
    @State private var model = ""
    @State private var plate = ""
    @State private var mileage = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Автомобиль") {
                    TextField("Марка", text: $brand)
                    TextField("Модель", text: $model)
                    TextField("Госномер", text: $plate)
                    TextField("Пробег", text: $mileage)
                        .keyboardType(.numberPad)
                }
            }
            .scrollContentBackground(.hidden)
            .background(PC.bg)
            .navigationTitle("Новый автомобиль")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Добавить") {
                        let vehicle = Vehicle(
                            brand: brand.isEmpty ? "Новый" : brand,
                            model: model.isEmpty ? "Автомобиль" : model,
                            plate: plate.isEmpty ? "—" : plate.uppercased(),
                            mileage: Int(mileage) ?? 0,
                            status: .idle,
                            nextService: "Не задано",
                            insurance: "Не задано"
                        )
                        onSave(vehicle)
                        dismiss()
                    }
                    .foregroundStyle(PC.yellow)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct NotificationsSheet: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    CompactAlert(icon: "wrench.fill", title: "Ремонт", detail: "2 автомобиля", color: PC.orange)
                    CompactAlert(icon: "shield.fill", title: "ОСАГО", detail: "1 заканчивается", color: PC.red)
                    CompactAlert(icon: "speedometer", title: "ТО", detail: "3 автомобиля", color: PC.yellow)
                }
                .padding(18)
            }
            .background(PC.bg)
            .navigationTitle("Уведомления")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                        .foregroundStyle(PC.yellow)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
