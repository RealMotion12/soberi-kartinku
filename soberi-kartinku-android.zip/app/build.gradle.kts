plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.realmotion12.soberikartinku"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.realmotion12.soberikartinku"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
