import express from "express";
import cors from "cors";
import pg from "pg";

const app = express();
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
app.use(cors());
app.use(express.json());

app.get("/health", async (_req, res) => {
  try { await pool.query("select 1"); res.json({ ok: true }); }
  catch { res.status(503).json({ ok: false }); }
});

app.get("/api/v1/vehicles", async (req, res) => {
  const org = req.header("X-Organization-Id");
  if (!org) return res.status(400).json({ error: "X-Organization-Id required" });
  const { rows } = await pool.query(
    `select id, brand, model, plate, mileage, status, next_service, insurance_until
     from vehicles where organization_id=$1 order by created_at desc`, [org]);
  res.json(rows);
});

app.post("/api/v1/vehicles", async (req, res) => {
  const org = req.header("X-Organization-Id");
  const { brand, model, plate, mileage=0, status="idle", nextService=null, insuranceUntil=null } = req.body;
  if (!org || !brand || !model || !plate)
    return res.status(400).json({ error: "organization, brand, model and plate are required" });
  const { rows } = await pool.query(
    `insert into vehicles(organization_id,brand,model,plate,mileage,status,next_service,insurance_until)
     values($1,$2,$3,$4,$5,$6,$7,$8)
     returning id,brand,model,plate,mileage,status,next_service,insurance_until`,
    [org,brand,model,plate,mileage,status,nextService,insuranceUntil]);
  res.status(201).json(rows[0]);
});

app.listen(process.env.PORT || 8080, () => console.log("ParkControl API started"));
