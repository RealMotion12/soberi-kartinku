package com.realmotion12.soberikartinku

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    data class Car(
        val brand: String,
        val model: String,
        val plate: String,
        var mileage: Int,
        var status: String = "На линии"
    )

    private val backgroundColor: Int = Color.rgb(18, 18, 18)
    private val cardColor: Int = Color.rgb(30, 30, 30)
    private val yellowColor: Int = Color.rgb(255, 204, 0)
    private val whiteColor: Int = Color.WHITE
    private val mutedColor: Int = Color.rgb(165, 165, 165)

    private val cars = mutableListOf(
        Car("Toyota", "Camry", "А123АА", 184250),
        Car("Kia", "Rio", "В456ВВ", 126800),
        Car("Hyundai", "Solaris", "С789СС", 97200),
        Car("Lada", "Vesta", "Е111ЕЕ", 201450, "В ремонте")
    )

    private val photoSteps = arrayOf("Спереди", "Слева", "Справа", "Сзади", "Багажник")
    private var photoIndex = 0
    private var selectedCar: Car? = null
    private var inspectionMileage: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
        requestNotificationPermission()
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun rootLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(backgroundColor)
            setPadding(dp(18), dp(18), dp(18), dp(10))
        }
    }

    private fun title(value: String, size: Float = 28f): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(whiteColor)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        }
    }

    private fun label(value: String): TextView {
        return TextView(this).apply {
            text = value
            textSize = 14f
            setTextColor(mutedColor)
            setPadding(0, dp(6), 0, dp(4))
        }
    }

    private fun actionButton(value: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = value
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.BLACK)
            setBackgroundColor(yellowColor)
            setOnClickListener { action() }
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(cardColor)
        }
    }

    private fun setScreen(view: View) {
        setContentView(view)
    }

    private fun showDashboard() {
        val root = rootLayout()
        root.addView(title("ПаркКонтроль"))
        root.addView(label("Управление автопарком"))

        val stats = card()
        stats.addView(label("ПАРК"))
        stats.addView(title("${cars.size} автомобилей", 25f))

        val row = LinearLayout(this)
        row.addView(statView("На линии", cars.count { it.status == "На линии" }.toString()),
            LinearLayout.LayoutParams(0, dp(70), 1.0f))
        row.addView(statView("Ремонт", cars.count { it.status == "В ремонте" }.toString()),
            LinearLayout.LayoutParams(0, dp(70), 1.0f))
        row.addView(statView("Осмотры", "15"),
            LinearLayout.LayoutParams(0, dp(70), 1.0f))
        stats.addView(row)
        root.addView(stats, LinearLayout.LayoutParams(-1, dp(190)))

        root.addView(label("БЫСТРЫЕ ДЕЙСТВИЯ"))
        root.addView(actionButton("🚗 Автомобили") { showCars() }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("🔧 Осмотры — сегодня 15") { showInspections() }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("👥 Сотрудники и права") { showEmployees() }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("⚙ Настройки и интеграции") { showSettings() }, LinearLayout.LayoutParams(-1, dp(55)))
        setScreen(root)
    }

    private fun statView(name: String, value: String): TextView {
        return TextView(this).apply {
            text = "$name\n$value"
            textSize = 14f
            setTextColor(whiteColor)
            gravity = Gravity.CENTER
            setPadding(4, 4, 4, 4)
        }
    }

    private fun showCars() {
        val root = rootLayout()
        root.addView(title("Автомобили"))
        root.addView(label("${cars.size} автомобилей в парке"))
        for (car in cars) {
            val item = card()
            item.addView(TextView(this).apply {
                text = "${car.brand} ${car.model}"
                textSize = 19f
                setTextColor(whiteColor)
                typeface = Typeface.DEFAULT_BOLD
            })
            item.addView(label("${car.plate} • ${car.mileage} км • ${car.status}"))
            item.addView(actionButton("Открыть") { showCar(car) })
            root.addView(item, LinearLayout.LayoutParams(-1, dp(125)).apply {
                setMargins(0, 0, 0, dp(10))
            })
        }
        root.addView(actionButton("← Назад") { showDashboard() })
        setScreen(root)
    }

    private fun showCar(car: Car) {
        val root = rootLayout()
        root.addView(title("${car.brand} ${car.model}"))
        root.addView(label(car.plate))

        val info = card()
        info.addView(label("СТАТУС"))
        info.addView(TextView(this).apply {
            text = car.status
            textSize = 22f
            setTextColor(yellowColor)
        })
        info.addView(label("Пробег: ${car.mileage} км"))
        root.addView(info, LinearLayout.LayoutParams(-1, dp(150)))

        root.addView(actionButton("🔧 Провести осмотр") { beginInspection(car) }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("🛠 Ремонт") { toast("Раздел ремонта") }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("📄 Документы") { toast("Документы автомобиля") }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("💰 Расходы") { toast("Расходы автомобиля") }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("← Назад") { showCars() })
        setScreen(root)
    }

    private fun showInspections() {
        val root = rootLayout()
        root.addView(title("Осмотры"))
        root.addView(label("СЕГОДНЯ"))

        val info = card()
        info.addView(TextView(this).apply {
            text = "15 осмотров"
            textSize = 24f
            setTextColor(yellowColor)
            typeface = Typeface.DEFAULT_BOLD
        })
        info.addView(label("12 на сегодня • 3 просрочено"))
        root.addView(info, LinearLayout.LayoutParams(-1, dp(120)))

        for (car in cars) {
            root.addView(actionButton("${car.brand} ${car.model} • ${car.plate}") {
                beginInspection(car)
            }, LinearLayout.LayoutParams(-1, dp(55)).apply {
                setMargins(0, 0, 0, dp(7))
            })
        }
        root.addView(actionButton("← Назад") { showDashboard() })
        setScreen(root)
    }

    private fun beginInspection(car: Car) {
        selectedCar = car
        val input = EditText(this).apply {
            hint = "Например, ${car.mileage}"
            inputType = 2
            setTextColor(whiteColor)
            setHintTextColor(mutedColor)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
            addView(label("ТЕКУЩИЙ ПРОБЕГ — ОБЯЗАТЕЛЬНО"))
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle("Начало осмотра")
            .setMessage("${car.brand} ${car.model} • ${car.plate}\nПредыдущий пробег: ${car.mileage} км")
            .setView(box)
            .setPositiveButton("Продолжить") { _, _ ->
                val mileage = input.text.toString().toIntOrNull()
                if (mileage == null) {
                    toast("Введите пробег")
                    return@setPositiveButton
                }
                if (mileage < car.mileage) {
                    toast("Пробег не может быть меньше предыдущего")
                    return@setPositiveButton
                }
                car.mileage = mileage
                inspectionMileage = mileage
                photoIndex = 0
                requestCameraPermission()
                showNextPhoto()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showNextPhoto() {
        if (photoIndex >= photoSteps.size) {
            showChecklist()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Фото ${photoIndex + 1} из ${photoSteps.size}")
            .setMessage("Сфотографируйте автомобиль: ${photoSteps[photoIndex]}")
            .setPositiveButton("📷 Камера") { _, _ -> openCamera() }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, 100)
    }

    private fun requestCameraPermission() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 10)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100) return
        if (resultCode == RESULT_OK) {
            toast("Фото ${photoSteps[photoIndex]} принято")
        } else {
            toast("Фото отменено")
        }
        photoIndex++
        showNextPhoto()
    }

    private fun showChecklist() {
        val root = rootLayout()
        root.addView(title("Чек-лист осмотра"))
        root.addView(label("${selectedCar?.plate ?: ""} • пробег $inspectionMileage км"))

        val items = arrayOf(
            "СТС",
            "Страховка",
            "Диагностическая карта",
            "Шашка",
            "Салон",
            "Аптечка",
            "Огнетушитель",
            "Знак аварийной остановки",
            "Запасное колесо",
            "Домкрат",
            "Ремень безопасности",
            "Фары",
            "Шины"
        )

        for (item in items) {
            root.addView(CheckBox(this).apply {
                text = "$item — есть / исправно"
                setTextColor(whiteColor)
                textSize = 16f
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }

        root.addView(actionButton("🔴 Отметить повреждения") {
            toast("Схема кузова будет открыта")
        }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("✓ Завершить осмотр") {
            toast("Осмотр сохранён")
            showInspections()
        }, LinearLayout.LayoutParams(-1, dp(55)))
        setScreen(root)
    }

    private fun showEmployees() {
        val root = rootLayout()
        root.addView(title("Сотрудники"))
        root.addView(label("Права доступа назначает администратор"))

        val users = arrayOf("Администратор", "Механик — Иван", "Механик — Алексей", "Наблюдатель")
        for (user in users) {
            val item = card()
            item.addView(TextView(this).apply {
                text = user
                textSize = 18f
                setTextColor(whiteColor)
                typeface = Typeface.DEFAULT_BOLD
            })
            val access = when {
                user.contains("Механик") -> "Осмотры • автомобили • фото"
                user.contains("Наблюдатель") -> "Только просмотр"
                else -> "Полный доступ"
            }
            item.addView(label(access))
            root.addView(item, LinearLayout.LayoutParams(-1, dp(100)).apply {
                setMargins(0, 0, 0, dp(8))
            })
        }
        root.addView(actionButton("+ Добавить сотрудника") { toast("Создание сотрудника") })
        root.addView(actionButton("← Назад") { showDashboard() })
        setScreen(root)
    }

    private fun showSettings() {
        val root = rootLayout()
        root.addView(title("Настройки"))
        root.addView(label("ОСМОТРЫ"))

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Каждые 1 день", "Каждые 7 дней", "Каждые 14 дней", "Каждые 30 дней")
        )
        root.addView(spinner, LinearLayout.LayoutParams(-1, dp(55)))

        root.addView(label("УВЕДОМЛЕНИЯ"))
        root.addView(Switch(this).apply {
            text = "Напоминать механику об осмотрах"
            setTextColor(whiteColor)
            isChecked = true
        }, LinearLayout.LayoutParams(-1, dp(55)))

        root.addView(label("ИНТЕГРАЦИЯ 1С"))
        root.addView(EditText(this).apply {
            hint = "URL REST-интерфейса 1С"
            setTextColor(whiteColor)
            setHintTextColor(mutedColor)
        }, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(actionButton("Сохранить подключение 1С") {
            toast("Настройки 1С сохранены")
        }, LinearLayout.LayoutParams(-1, dp(55)))

        root.addView(label("EXCEL"))
        root.addView(actionButton("📥 Импорт парка из Excel") {
            toast("Импорт Excel будет подключён следующим шагом")
        }, LinearLayout.LayoutParams(-1, dp(55)))

        root.addView(actionButton("← Назад") { showDashboard() })
        setScreen(root)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
